package com.example.btceventsignal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("signal_history", Context.MODE_PRIVATE)

    @Synchronized fun add(signal: Signal) {
        val list = read().toMutableList()
        if (list.firstOrNull()?.time == signal.candleTime) return
        list.add(0, SignalRecord(signal.direction.name, signal.score, signal.price, signal.candleTime))
        write(list.take(200))
    }

    @Synchronized fun setLatestOutcome(outcome: String) {
        val list = read().toMutableList()
        if (list.isNotEmpty()) {
            list[0] = list[0].copy(outcome = outcome)
            write(list)
        }
    }

    @Synchronized fun read(): List<SignalRecord> {
        val raw = prefs.getString("records", "[]") ?: "[]"
        val a = JSONArray(raw)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            SignalRecord(o.getString("direction"), o.getInt("score"), o.getDouble("price"),
                o.getLong("time"), o.optString("outcome", "待记录"))
        }
    }

    private fun write(records: List<SignalRecord>) {
        val a = JSONArray()
        records.forEach {
            a.put(JSONObject().put("direction", it.direction).put("score", it.score)
                .put("price", it.price).put("time", it.time).put("outcome", it.outcome))
        }
        prefs.edit().putString("records", a.toString()).apply()
    }
}
