package com.example.btceventsignal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class MonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val feed = BinanceFeed()
    private lateinit var history: HistoryStore
    private var one = mutableListOf<Candle>()
    private var five = mutableListOf<Candle>()
    private var fifteen = mutableListOf<Candle>()
    private var lastSignalKey: Long = -1L
    private var lastNotificationAt = 0L

    override fun onCreate() {
        super.onCreate()
        history = HistoryStore(this)
        createChannel()
        startForeground(NOTIFICATION_ID, notification("正在启动 BTC 行情监控"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (scope.coroutineContext[Job]?.isActive != true || !started) {
            started = true
            scope.launch { runMonitor() }
        }
        return START_STICKY
    }

    @Volatile private var started = false

    private suspend fun runMonitor() {
        var backoff = 2L
        while (scope.isActive) {
            try {
                one = feed.load("1m").toMutableList()
                five = feed.load("5m").toMutableList()
                fifteen = feed.load("15m").toMutableList()
                sendUi("历史行情已加载，正在连接实时数据", one.lastOrNull()?.close, null)
                backoff = 2L
                feed.stream(
                    onStatus = { status ->
                        updateNotification(status)
                        sendUi(status, one.lastOrNull()?.close, null)
                    },
                    onCandle = { interval, candle ->
                        val list = when (interval) { "1m" -> one; "5m" -> five; else -> fifteen }
                        synchronized(list) {
                            val ix = list.indexOfFirst { it.openTime == candle.openTime }
                            if (ix >= 0) list[ix] = candle else list.add(candle)
                            while (list.size > 250) list.removeAt(0)
                        }
                        if (interval == "1m") {
                            val s = SignalEngine.evaluate(one.toList(), five.toList(), fifteen.toList())
                            if (s != null && s.direction != Direction.WAIT && s.candleTime != lastSignalKey) {
                                lastSignalKey = s.candleTime
                                history.add(s)
                                if (System.currentTimeMillis() - lastNotificationAt > 30_000) {
                                    notifySignal(s)
                                    lastNotificationAt = System.currentTimeMillis()
                                }
                                sendUi("发现候选信号，请人工核对", s.price, s)
                            } else {
                                sendUi("监控中", candle.close, s)
                            }
                        } else {
                            sendUi("监控中", one.lastOrNull()?.close, null)
                        }
                    }
                )
            } catch (e: Exception) {
                val msg = "行情连接异常：${e.message ?: "未知错误"}；${backoff}秒后重试"
                updateNotification(msg)
                sendUi(msg, one.lastOrNull()?.close, null)
            }
            delay(backoff * 1000)
            backoff = (backoff * 2).coerceAtMost(60)
        }
    }

    private fun sendUi(status: String, price: Double?, signal: Signal?) {
        val i = Intent(ACTION_UPDATE).setPackage(packageName)
            .putExtra("status", status).putExtra("price", price ?: -1.0)
        if (signal != null) {
            i.putExtra("direction", signal.direction.name)
            i.putExtra("score", signal.score)
            i.putExtra("signalPrice", signal.price)
            i.putExtra("candleTime", signal.candleTime)
            i.putStringArrayListExtra("reasons", ArrayList(signal.reasons))
        }
        sendBroadcast(i)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "BTC行情监控", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BTC 事件合约助手")
            .setContentText(message)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(message))
    }

    private fun notifySignal(s: Signal) {
        val direction = if (s.direction == Direction.UP) "候选买涨" else "候选买跌"
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BTC 出现候选信号：$direction")
            .setContentText("参考价 ${"%.2f".format(s.price)} · 评分 ${s.score}/8 · 请人工核对")
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify((s.candleTime % Int.MAX_VALUE).toInt(), n)
    }

    override fun onDestroy() {
        started = false
        scope.cancel()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.example.btceventsignal.UPDATE"
        const val ACTION_STOP = "com.example.btceventsignal.STOP"
        private const val CHANNEL_ID = "btc_monitor"
        private const val NOTIFICATION_ID = 1001
    }
}
