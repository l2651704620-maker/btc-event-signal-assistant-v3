package com.example.btceventsignal

/** 三周期一致性过滤：15m 定方向、5m 确认趋势、1m 触发；不一致一律观望。 */
object SignalEngine {
    fun evaluate(oneMinute: List<Candle>, fiveMinute: List<Candle>, fifteenMinute: List<Candle>): Signal? {
        val a = oneMinute.filter { it.closed }.takeLast(120)
        val b = fiveMinute.filter { it.closed }.takeLast(120)
        val c = fifteenMinute.filter { it.closed }.takeLast(120)
        if (a.size < 35 || b.size < 35 || c.size < 35) return null
        val c1 = a.map { it.close }; val c5 = b.map { it.close }; val c15 = c.map { it.close }
        val up15 = ema(c15, 9) > ema(c15, 21)
        val down15 = ema(c15, 9) < ema(c15, 21)
        val up5 = ema(c5, 9) > ema(c5, 21)
        val down5 = ema(c5, 9) < ema(c5, 21)
        val up1 = ema(c1, 9) > ema(c1, 21)
        val down1 = ema(c1, 9) < ema(c1, 21)
        val r = rsi(c1, 14)
        val h0 = macdHistogram(c1); val h1 = macdHistogram(c1.dropLast(1))
        val avgVol = a.takeLast(21).dropLast(1).map { it.volume }.average()
        val volOk = avgVol > 0 && a.last().volume > avgVol * 1.05
        val upMomentum = r in 52.0..70.0 && h0 > 0 && h0 > h1
        val downMomentum = r in 30.0..48.0 && h0 < 0 && h0 < h1
        val reasons = when {
            up15 && up5 && up1 && upMomentum -> buildList {
                add("15分钟 EMA 趋势向上"); add("5分钟 EMA 确认向上"); add("1分钟 EMA 入场方向向上")
                add("RSI 动量偏强 (${r.toInt()})"); add("MACD 柱体增强"); if (volOk) add("成交量高于近期均量")
            }
            down15 && down5 && down1 && downMomentum -> buildList {
                add("15分钟 EMA 趋势向下"); add("5分钟 EMA 确认向下"); add("1分钟 EMA 入场方向向下")
                add("RSI 动量偏弱 (${r.toInt()})"); add("MACD 柱体走弱"); if (volOk) add("成交量高于近期均量")
            }
            else -> listOf("15分钟、5分钟、1分钟方向或动能未全部一致，观望")
        }
        val direction = when {
            up15 && up5 && up1 && upMomentum -> Direction.UP
            down15 && down5 && down1 && downMomentum -> Direction.DOWN
            else -> Direction.WAIT
        }
        val score = if (direction == Direction.WAIT) 0 else (5 + if (volOk) 1 else 0).coerceAtMost(6)
        return Signal(direction, score, a.last().close, reasons, a.last().openTime)
    }

    private fun ema(v: List<Double>, n: Int): Double {
        val k = 2.0 / (n + 1)
        return v.drop(1).fold(v.first()) { x, y -> y * k + x * (1 - k) }
    }
    private fun rsi(v: List<Double>, n: Int): Double {
        val d = v.zipWithNext { x, y -> y - x }.takeLast(n)
        val gain = d.filter { it > 0 }.sum() / n
        val loss = -d.filter { it < 0 }.sum() / n
        if (loss == 0.0) return 100.0
        val rs = gain / loss
        return 100.0 - 100.0 / (1.0 + rs)
    }
    private fun macdHistogram(v: List<Double>): Double {
        if (v.size < 35) return 0.0
        val line = v.indices.map { i ->
            val p = v.take(i + 1)
            if (p.size < 26) 0.0 else ema(p, 12) - ema(p, 26)
        }
        val valid = line.drop(25)
        if (valid.size < 9) return 0.0
        return valid.last() - ema(valid, 9)
    }
}
