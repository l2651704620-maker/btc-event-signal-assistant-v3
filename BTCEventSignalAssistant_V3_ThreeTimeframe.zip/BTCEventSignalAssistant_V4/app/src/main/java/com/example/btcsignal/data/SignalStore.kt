package com.example.btcsignal.data

import android.content.Context
import com.example.btcsignal.model.*
import org.json.JSONArray
import org.json.JSONObject

class SignalStore(context: Context) {
    private val prefs = context.getSharedPreferences("signal_store_v4", Context.MODE_PRIVATE)
    @Synchronized fun all(): List<SignalRecord> {
        val arr = JSONArray(prefs.getString("records", "[]"))
        return (0 until arr.length()).mapNotNull { i -> runCatching { decode(arr.getJSONObject(i)) }.getOrNull() }.sortedByDescending { it.createdAt }
    }
    @Synchronized fun add(record: SignalRecord) { save((all().filterNot { it.id == record.id } + record).take(500)) }
    @Synchronized fun snapshot(id: String, snap: PriceSnapshot) {
        val updated = all().map { r -> if (r.id == id && r.snapshots.none { it.offsetMinutes == snap.offsetMinutes }) r.copy(snapshots = r.snapshots + snap) else r }
        save(updated)
    }
    @Synchronized fun outcome(id: String, value: String) { save(all().map { if (it.id == id) it.copy(outcome = value) else it }) }
    fun canCreate(key: String, now: Long): Boolean {
        val localDayStart = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val distinctSignalTimes = all().filter { it.createdAt >= localDayStart }.map { it.createdAt }.distinct().size
        return distinctSignalTimes < 3 && now - prefs.getLong("cool_$key", 0L) >= 60 * 60 * 1000L
    }
    fun markCreated(key: String, now: Long) { prefs.edit().putLong("cool_$key", now).apply() }
    private fun save(records: List<SignalRecord>) { prefs.edit().putString("records", JSONArray().apply { records.forEach { put(encode(it)) } }.toString()).apply() }
    private fun encode(r: SignalRecord) = JSONObject().apply {
        put("id",r.id); put("createdAt",r.createdAt); put("horizon",r.horizonMinutes); put("direction",r.direction.name); put("score",r.score); put("reference",r.referencePrice); put("invalidation",r.invalidationPrice); put("target",r.targetPrice); put("reasons",JSONArray(r.reasons)); put("outcome",r.outcome)
        put("snapshots",JSONArray().apply { r.snapshots.forEach { put(JSONObject().put("offset",it.offsetMinutes).put("price",it.price).put("time",it.capturedAt)) } })
    }
    private fun decode(o: JSONObject): SignalRecord {
        val reasons = o.getJSONArray("reasons"); val snaps = o.getJSONArray("snapshots")
        return SignalRecord(o.getString("id"),o.getLong("createdAt"),o.getInt("horizon"),Direction.valueOf(o.getString("direction")),o.getInt("score"),o.getDouble("reference"),o.getDouble("invalidation"),o.getDouble("target"),(0 until reasons.length()).map { reasons.getString(it) },(0 until snaps.length()).map { val s=snaps.getJSONObject(it); PriceSnapshot(s.getInt("offset"),s.getDouble("price"),s.getLong("time")) },o.optString("outcome","PENDING"))
    }
}
