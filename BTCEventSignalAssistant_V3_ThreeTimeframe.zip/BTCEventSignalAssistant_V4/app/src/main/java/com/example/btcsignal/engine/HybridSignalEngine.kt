package com.example.btcsignal.engine

import com.example.btcsignal.model.Candle
import com.example.btcsignal.model.Direction
import com.example.btcsignal.model.Prediction

object HybridSignalEngine {
    private data class Scores(val long: Int, val short: Int, val longReasons: List<String>, val shortReasons: List<String>)

    fun evaluate(price: Double, h4: List<Candle>, h1: List<Candle>, m30: List<Candle>, m15: List<Candle>): List<Prediction> {
        if (h4.size < 205 || h1.size < 60 || m30.size < 60 || m15.size < 30) return emptyList()
        val thirty = score30(h1, m30, m15)
        val hour = score60(h4, h1)
        return listOf(
            makePrediction(30, thirty, price, m30),
            makePrediction(60, hour, price, h1)
        )
    }

    private fun score30(h1: List<Candle>, m30: List<Candle>, m15: List<Candle>): Scores {
        val long = mutableListOf<String>(); val short = mutableListOf<String>(); var l = 0; var s = 0
        val h1v = h1.map { it.close }; val v = m30.map { it.close }; val a = Indicators.atr(m15)
        if (Indicators.ema(h1v,20) > Indicators.ema(h1v,50)) { l += 15; long += "1小时EMA20高于EMA50" } else { s += 15; short += "1小时EMA20低于EMA50" }
        if (Indicators.structureBullish(m30)) { l += 25; long += "30分钟高点与低点抬高" }
        if (Indicators.structureBearish(m30)) { s += 25; short += "30分钟高点与低点降低" }
        if (Indicators.breakout(m30,true)) { l += 20; long += "30分钟收盘突破近20根高点" }
        if (Indicators.breakout(m30,false)) { s += 20; short += "30分钟收盘跌破近20根低点" }
        val rsi = Indicators.rsi(v)
        if (rsi > 55 && Indicators.macdBullish(v)) { l += 15; long += "RSI与MACD支持多头" }
        if (rsi < 45 && !Indicators.macdBullish(v)) { s += 15; short += "RSI与MACD支持空头" }
        val vol = Indicators.volumeRatio(m30)
        if (vol >= 1.2 && m30.last().close > m30.last().open) { l += 15; long += "放量阳线确认" }
        if (vol >= 1.2 && m30.last().close < m30.last().open) { s += 15; short += "放量阴线确认" }
        val adx = Indicators.adxApprox(m15)
        if (adx >= 20 && a > 0) { l += 5; s += 5 }
        if (adx < 15) { l = (l - 10).coerceAtLeast(0); s = (s - 10).coerceAtLeast(0) }
        return Scores(l.coerceAtMost(100), s.coerceAtMost(100), long, short)
    }

    private fun score60(h4: List<Candle>, h1: List<Candle>): Scores {
        val long = mutableListOf<String>(); val short = mutableListOf<String>(); var l = 0; var s = 0
        val h4v = h4.map { it.close }; val v = h1.map { it.close }
        if (Indicators.ema(h4v,50) > Indicators.ema(h4v,200)) { l += 20; long += "4小时EMA50高于EMA200" } else { s += 20; short += "4小时EMA50低于EMA200" }
        if (Indicators.ema(v,20) > Indicators.ema(v,50)) { l += 20; long += "1小时EMA20高于EMA50" } else { s += 20; short += "1小时EMA20低于EMA50" }
        if (Indicators.structureBullish(h1)) { l += 20; long += "1小时结构为高点抬高、低点抬高" }
        if (Indicators.structureBearish(h1)) { s += 20; short += "1小时结构为高点降低、低点降低" }
        if (Indicators.breakout(h1,true)) { l += 15; long += "1小时收盘突破区间" }
        if (Indicators.breakout(h1,false)) { s += 15; short += "1小时收盘跌破区间" }
        val rsi = Indicators.rsi(v)
        if (rsi > 55 && Indicators.macdBullish(v)) { l += 10; long += "1小时动能偏多" }
        if (rsi < 45 && !Indicators.macdBullish(v)) { s += 10; short += "1小时动能偏空" }
        val vol = Indicators.volumeRatio(h1)
        if (vol >= 1.2 && h1.last().close > h1.last().open) { l += 10; long += "1小时成交量放大且收阳" }
        if (vol >= 1.2 && h1.last().close < h1.last().open) { s += 10; short += "1小时成交量放大且收阴" }
        val adx = Indicators.adxApprox(h1)
        if (adx >= 20) { l += 5; s += 5 }
        return Scores(l.coerceAtMost(100), s.coerceAtMost(100), long, short)
    }

    private fun makePrediction(minutes: Int, scores: Scores, price: Double, candles: List<Candle>): Prediction {
        val longWins = scores.long >= scores.short
        val direction = if (longWins) Direction.LONG else Direction.SHORT
        val score = if (longWins) scores.long else scores.short
        val reasons = if (longWins) scores.longReasons else scores.shortReasons
        val atr = Indicators.atr(candles).takeIf { it > 0 } ?: price * 0.003
        val stop = if (direction == Direction.LONG) price - 1.5 * atr else price + 1.5 * atr
        val target = if (direction == Direction.LONG) price + 3.0 * atr else price - 3.0 * atr
        return Prediction(minutes, if (score < 75) Direction.NEUTRAL else direction, score, reasons, price, stop, target)
    }
}
