package com.example.btcsignal

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.work.*
import com.example.btcsignal.data.BinanceRepository
import com.example.btcsignal.data.SignalStore
import com.example.btcsignal.worker.SignalScanWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { SignalScreen() } }
    }

    @Composable private fun SignalScreen() {
        var records by remember { mutableStateOf(SignalStore(this).all()) }
        var price by remember { mutableStateOf("读取中…") }
        var status by remember { mutableStateOf("监控未启动") }
        var busy by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        fun refresh() { records = SignalStore(this).all() }
        LaunchedEffect(Unit) {
            price = withContext(Dispatchers.IO) { runCatching { "%.2f USDT".format(BinanceRepository().latestPrice()) }.getOrElse { "行情读取失败" } }
        }
        val done30 = records.filter { it.horizonMinutes == 30 && it.outcome in listOf("CORRECT", "WRONG") }
        val done60 = records.filter { it.horizonMinutes == 60 && it.outcome in listOf("CORRECT", "WRONG") }
        fun accuracy(items: List<com.example.btcsignal.model.SignalRecord>): String = if (items.isEmpty()) "暂无" else "${(items.count { it.outcome == "CORRECT" } * 100 / items.size)}% (${items.size}笔)"
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("BTC 智能信号助手 V4.0", style = MaterialTheme.typography.headlineSmall)
            Text("BTCUSDT 永续 · 仅提示，不自动下单")
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("最新参考价格"); Text(price, style = MaterialTheme.typography.headlineMedium); Text(status) } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { runCatching { "%.2f USDT".format(BinanceRepository().latestPrice()) }.getOrElse { "行情读取失败：${it.message}" } }
                        price = result; busy = false
                    }
                }) { Text("刷新价格") }
                Button(onClick = {
                    val request = PeriodicWorkRequestBuilder<SignalScanWorker>(15, TimeUnit.MINUTES).build()
                    WorkManager.getInstance(this@MainActivity).enqueueUniquePeriodicWork("btc_signal_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
                    WorkManager.getInstance(this@MainActivity).enqueue(OneTimeWorkRequestBuilder<SignalScanWorker>().build())
                    status = "监控已启动（约每15分钟扫描）"
                }) { Text("启动监控") }
                OutlinedButton(onClick = {
                    WorkManager.getInstance(this@MainActivity).cancelUniqueWork("btc_signal_monitor")
                    status = "监控已停止"
                }) { Text("停止") }
            }
            OutlinedButton(onClick = { WorkManager.getInstance(this@MainActivity).enqueue(OneTimeWorkRequestBuilder<SignalScanWorker>().build()); status = "正在执行一次扫描" }) { Text("立即扫描一次") }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("方向判断统计", style = MaterialTheme.typography.titleMedium)
                    Text("30分钟：${accuracy(done30)}    1小时：${accuracy(done60)}")
                    Text("仅统计已完成的方向判定；不代表扣除手续费后的交易收益。", style = MaterialTheme.typography.bodySmall)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("历史信号（${records.size}）", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { refresh() }) { Text("刷新记录") }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${r.horizonMinutes}分钟 · ${if (r.direction.name == "LONG") "看涨" else "看跌"} · ${r.score}/100", style = MaterialTheme.typography.titleMedium)
                            Text("信号参考价：${"%.2f".format(r.referencePrice)} USDT")
                            Text("失效价：${"%.2f".format(r.invalidationPrice)} · 目标价：${"%.2f".format(r.targetPrice)}")
                            r.snapshots.sortedBy { it.offsetMinutes }.forEach { s -> Text("T+${s.offsetMinutes}分钟快照：${"%.2f".format(s.price)} USDT（实际 ${((s.capturedAt-r.createdAt)/60000.0).let { "%.1f".format(it) }} 分钟）") }
                            Text("方向判定：${when(r.outcome) { "CORRECT" -> "正确"; "WRONG" -> "错误"; "DRAW" -> "平局"; else -> "待判定" }}")
                            if (r.reasons.isNotEmpty()) Text("理由：${r.reasons.joinToString("；")}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
