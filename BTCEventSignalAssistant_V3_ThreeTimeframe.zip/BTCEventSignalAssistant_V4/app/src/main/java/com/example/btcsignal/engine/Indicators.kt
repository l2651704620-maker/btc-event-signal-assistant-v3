package com.example.btcsignal.engine

import com.example.btcsignal.model.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object Indicators {
    fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val k = 2.0 / (period + 1.0)
        var e = values.take(period).average()
        for (v in values.drop(period)) e = v * k + e * (1 - k)
        return e
    }
    fun rsi(values: List<Double>, period: Int = 14): Double {
        if (values.size <= period) return 50.0
        val changes = values.zipWithNext { a, b -> b - a }
        var gain = changes.take(period).sumOf { max(it, 0.0) } / period
        var loss = changes.take(period).sumOf { max(-it, 0.0) } / period
        for (d in changes.drop(period)) { gain = (gain * (period - 1) + max(d, 0.0)) / period; loss = (loss * (period - 1) + max(-d, 0.0)) / period }
        if (loss == 0.0) return 100.0
        return 100.0 - 100.0 / (1.0 + gain / loss)
    }
    fun macdBullish(values: List<Double>): Boolean {
        if (values.size < 40) return false
        val fast = values.takeLast(35).let { ema(it, 12) }
        val slow = values.takeLast(35).let { ema(it, 26) }
        val prev = values.dropLast(1).takeLast(35)
        return fast > slow && ema(prev, 12) <= ema(prev, 26) || fast > slow
    }
    fun atr(c: List<Candle>, period: Int = 14): Double {
        if (c.size < period + 1) return c.lastOrNull()?.let { it.high - it.low } ?: 0.0
        val tr = c.zipWithNext().map { (p, n) -> max(n.high - n.low, max(abs(n.high - p.close), abs(n.low - p.close))) }
        return tr.takeLast(period).average()
    }
    fun adxApprox(c: List<Candle>, period: Int = 14): Double {
        if (c.size < period + 2) return 0.0
        val recent = c.takeLast(period + 1)
        val up = recent.zipWithNext().sumOf { (a,b) -> max(b.high - a.high, 0.0) }
        val down = recent.zipWithNext().sumOf { (a,b) -> max(a.low - b.low, 0.0) }
        val total = up + down
        return if (total == 0.0) 0.0 else abs(up - down) / total * 100.0
    }
    fun volumeRatio(c: List<Candle>): Double {
        if (c.size < 21) return 1.0
        val avg = c.dropLast(1).takeLast(20).map { it.volume }.average()
        return if (avg <= 0) 1.0 else c.last().volume / avg
    }
    fun structureBullish(c: List<Candle>): Boolean {
        if (c.size < 8) return false
        val x = c.takeLast(8)
        val firstHigh = x.take(4).maxOf { it.high }; val lastHigh = x.takeLast(4).maxOf { it.high }
        val firstLow = x.take(4).minOf { it.low }; val lastLow = x.takeLast(4).minOf { it.low }
        return lastHigh > firstHigh && lastLow > firstLow
    }
    fun structureBearish(c: List<Candle>): Boolean {
        if (c.size < 8) return false
        val x = c.takeLast(8)
        val firstHigh = x.take(4).maxOf { it.high }; val lastHigh = x.takeLast(4).maxOf { it.high }
        val firstLow = x.take(4).minOf { it.low }; val lastLow = x.takeLast(4).minOf { it.low }
        return lastHigh < firstHigh && lastLow < firstLow
    }
    fun breakout(c: List<Candle>, bullish: Boolean): Boolean {
        if (c.size < 22) return false
        val prev = c.dropLast(1).takeLast(20)
        val last = c.last()
        val a = atr(c)
        return if (bullish) last.close > prev.maxOf { it.high } + a * 0.1 else last.close < prev.minOf { it.low } - a * 0.1
    }
}
