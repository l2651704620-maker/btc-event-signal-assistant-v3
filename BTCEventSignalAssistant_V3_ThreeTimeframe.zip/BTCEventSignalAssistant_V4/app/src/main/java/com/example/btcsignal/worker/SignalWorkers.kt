package com.example.btcsignal.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.example.btcsignal.R
import com.example.btcsignal.data.BinanceRepository
import com.example.btcsignal.data.SignalStore
import com.example.btcsignal.engine.HybridSignalEngine
import com.example.btcsignal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID
import java.util.concurrent.TimeUnit

class SignalScanWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val api = BinanceRepository(); val now = System.currentTimeMillis()
            fun closed(interval: String, limit: Int) = api.candles(interval, limit).filter { it.closeTime < now - 1000 }
            val h4 = closed("4h", 240); val h1 = closed("1h", 240); val m30 = closed("30m", 240); val m15 = closed("15m", 240)
            val price = api.latestPrice()
            val predictions = HybridSignalEngine.evaluate(price, h4, h1, m30, m15)
            val store = SignalStore(applicationContext)
            predictions.filter { it.score >= 85 && it.direction != Direction.NEUTRAL }.forEach { p ->
                val key = "${p.horizonMinutes}_${p.direction.name}"
                if (store.canCreate(key, now)) {
                    val id = "BTC-${p.horizonMinutes}-${now}-${UUID.randomUUID().toString().take(6)}"
                    val record = SignalRecord(id, now, p.horizonMinutes, p.direction, p.score, price, p.invalidationPrice, p.targetPrice, p.reasons)
                    store.add(record); store.markCreated(key, now)
                    notifySignal(record)
                    listOf(10, 30, 60).forEach { offset ->
                        val request = OneTimeWorkRequestBuilder<PriceSnapshotWorker>()
                            .setInitialDelay(offset.toLong(), TimeUnit.MINUTES)
                            .setInputData(workDataOf("signal_id" to id, "offset" to offset))
                            .build()
                        WorkManager.getInstance(applicationContext).enqueueUniqueWork("snapshot_${id}_$offset", ExistingWorkPolicy.KEEP, request)
                    }
                }
            }
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun notifySignal(r: SignalRecord) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("btc_signals", "BTC信号提醒", NotificationManager.IMPORTANCE_HIGH))
        val side = if (r.direction == Direction.LONG) "看涨" else "看跌"
        val n = NotificationCompat.Builder(applicationContext, "btc_signals")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BTC ${r.horizonMinutes}分钟强信号：$side")
            .setContentText("评分 ${r.score}/100 · 参考价 ${"%.2f".format(r.referencePrice)} USDT")
            .setStyle(NotificationCompat.BigTextStyle().bigText(r.reasons.joinToString("；")))
            .setAutoCancel(true).build()
        manager.notify(r.id.hashCode(), n)
    }
}

class PriceSnapshotWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val id = inputData.getString("signal_id") ?: return@withContext Result.failure()
        val offset = inputData.getInt("offset", -1)
        if (offset !in listOf(10, 30, 60)) return@withContext Result.failure()
        try {
            val store = SignalStore(applicationContext)
            val record = store.all().firstOrNull { it.id == id } ?: return@withContext Result.failure()
            val targetTime = record.createdAt + offset * 60_000L
            val quote = BinanceRepository().snapshotAt(targetTime)
            val price = quote.first
            store.snapshot(id, PriceSnapshot(offset, price, quote.second))
            if (offset == record.horizonMinutes) {
                val result = when {
                    kotlin.math.abs(price - record.referencePrice) < 0.01 -> "DRAW"
                    record.direction == Direction.LONG && price > record.referencePrice -> "CORRECT"
                    record.direction == Direction.SHORT && price < record.referencePrice -> "CORRECT"
                    else -> "WRONG"
                }
                store.outcome(id, result)
            }
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }
}
