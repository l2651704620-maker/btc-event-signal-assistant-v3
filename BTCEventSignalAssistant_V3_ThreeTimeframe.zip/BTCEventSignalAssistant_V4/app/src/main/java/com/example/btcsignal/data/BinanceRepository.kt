package com.example.btcsignal.data

import com.example.btcsignal.model.Candle
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class BinanceRepository {
    private val client = OkHttpClient.Builder().callTimeout(12, TimeUnit.SECONDS).build()
    private val base = "https://fapi.binance.com"

    private fun get(path: String): String {
        val request = Request.Builder().url(base + path).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Binance HTTP ${response.code}")
            return response.body?.string() ?: error("Empty Binance response")
        }
    }

    fun candles(interval: String, limit: Int = 250): List<Candle> {
        val json = JSONArray(get("/fapi/v1/klines?symbol=BTCUSDT&interval=$interval&limit=$limit"))
        return (0 until json.length()).map { i ->
            val a = json.getJSONArray(i)
            Candle(a.getLong(0), a.getString(1).toDouble(), a.getString(2).toDouble(), a.getString(3).toDouble(), a.getString(4).toDouble(), a.getString(5).toDouble(), a.getLong(6))
        }
    }

    fun latestPrice(): Double = JSONObject(get("/fapi/v1/ticker/price?symbol=BTCUSDT")).getString("price").toDouble()

    // Select the last fully closed 1-minute candle at or immediately before the target time.
    // This allows a delayed Android background worker to recover the intended historical snapshot.
    fun snapshotAt(targetTime: Long): Pair<Double, Long> {
        val targetMinute = (targetTime / 60_000L) * 60_000L
        val candleOpen = targetMinute - 60_000L
        val json = JSONArray(get("/fapi/v1/klines?symbol=BTCUSDT&interval=1m&startTime=$candleOpen&endTime=${candleOpen + 59_999L}&limit=1"))
        if (json.length() == 0) error("No completed 1m candle for snapshot")
        val candle = json.getJSONArray(0)
        return candle.getString(4).toDouble() to candle.getLong(6)
    }
}
