package com.example.btcsignal.model

data class Candle(val openTime: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double, val closeTime: Long)
enum class Direction { LONG, SHORT, NEUTRAL }
data class Prediction(val horizonMinutes: Int, val direction: Direction, val score: Int, val reasons: List<String>, val entryPrice: Double, val invalidationPrice: Double, val targetPrice: Double)
data class PriceSnapshot(val offsetMinutes: Int, val price: Double, val capturedAt: Long)
data class SignalRecord(
    val id: String,
    val createdAt: Long,
    val horizonMinutes: Int,
    val direction: Direction,
    val score: Int,
    val referencePrice: Double,
    val invalidationPrice: Double,
    val targetPrice: Double,
    val reasons: List<String>,
    val snapshots: List<PriceSnapshot> = emptyList(),
    val outcome: String = "PENDING"
)
