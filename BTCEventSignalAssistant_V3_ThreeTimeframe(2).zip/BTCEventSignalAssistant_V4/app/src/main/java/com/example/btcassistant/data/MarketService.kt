package com.example.btcassistant.data

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class MarketService : Service() {
    companion object {
        const val ACTION_PREDICT_10 = "com.example.btcassistant.PREDICT_10"
        const val ACTION_PREDICT_30 = "com.example.btcassistant.PREDICT_30"
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).connectTimeout(15, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).build()
    private var socket: WebSocket? = null
    private var reconnectDelay = 2L
    private var predicting10 = false
    private var predicting30 = false

    override fun onCreate() {
        super.onCreate(); SignalStore.load(this)
        startForeground(51, notification("正在连接币安行情")); connect()
        scope.launch { snapshotLoop() }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PREDICT_10 -> if (!predicting10) scope.launch { runPrediction(10) }
            ACTION_PREDICT_30 -> if (!predicting30) scope.launch { runPrediction(30) }
        }
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { socket?.close(1000, "service stopped"); scope.cancel(); super.onDestroy() }

    private fun notification(s: String): Notification {
        val channel = "btc_market_v5"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"BTC行情监控",NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this,channel).setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("BTC信号助手 V5").setContentText(s).setOngoing(true).build()
    }
    private fun updateNotification(s: String) { if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).notify(51,notification(s)) }
    private fun connect() {
        val req = Request.Builder().url("wss://fstream.binance.com/stream?streams=btcusdt@markPrice@1s").build()
        socket = client.newWebSocket(req, object: WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { reconnectDelay=2; SignalStore.setConnected(true); updateNotification("BTC实时行情连接正常") }
            override fun onMessage(webSocket: WebSocket, text: String) { runCatching { val root=JSONObject(text); val d=root.optJSONObject("data") ?: root; SignalStore.setPrice(d.optString("p").toDouble()) } }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { SignalStore.setConnected(false); scheduleReconnect() }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { SignalStore.setConnected(false); scheduleReconnect() }
        })
    }
    private fun scheduleReconnect() { scope.launch { delay(reconnectDelay*1000); reconnectDelay=(reconnectDelay*2).coerceAtMost(60); connect() } }

    private suspend fun runPrediction(horizon: Int) {
        if (horizon == 10) predicting10 = true else predicting30 = true
        SignalStore.setStatus(horizon, "正在读取${if(horizon==10) "最近3分钟" else "最近10分钟"}行情并分析…")
        val requestedAt = System.currentTimeMillis()
        val referencePrice = SignalStore.price.value
        try {
            if (SignalStore.hasPending(horizon)) { SignalStore.setStatus(horizon, "上一笔预测尚未结算，请稍后再启动"); return }
            if (SignalStore.price.value <= 0 || !SignalStore.connected.value) error("尚未连接到币安实时行情")
            val config = SignalStore.aiConfig(this)
            if (config.third.isBlank()) error("尚未配置AI接口。请先点右上角设置，填写AI服务地址、模型和API Key")
            val oneMin = fetchKlines("1m", if (horizon == 10) 12 else 15)
            val fiveMin = fetchKlines("5m", 12)
            val fifteenMin = fetchKlines("15m", 8)
            val extras = fetchExtraMarketData()
            val market = buildMarketSummary(oneMin, fiveMin, fifteenMin, horizon) + "\nAdditional derivatives data: $extras"
            SignalStore.setStatus(horizon, "行情已读取，AI正在综合研判…")
            val answer = askAi(config.first, config.second, config.third, horizon, market)
            val side = answer.optString("direction", "观望")
            val confidence = answer.optInt("confidence", 0).coerceIn(0,100)
            val reason = answer.optString("reason", "AI未提供分析理由")
            if (side !in listOf("看涨", "看跌") || confidence < 75) {
                SignalStore.setStatus(horizon, "本次不推送：AI判断为观望或置信度不足（${confidence}%）")
            } else {
                if (referencePrice <= 0) error("实时价格暂不可用，未创建预测")
                SignalStore.add(this, PredictionRecord(requestedAt, horizon, side, referencePrice, requestedAt, requestedAt + horizon*60_000L, confidence, reason))
                SignalStore.setStatus(horizon, "已推送$side · ${confidence}% · ${horizon}分钟后自动结算")
                updateNotification("${horizon}分钟智能预测：$side，请人工确认")
            }
        } catch (e: Exception) {
            SignalStore.setStatus(horizon, "分析失败：${e.message ?: "网络或AI服务异常"}")
        } finally {
            if (horizon == 10) predicting10 = false else predicting30 = false
        }
    }

    private data class Candle(val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double, val changePct: Double)
    private suspend fun fetchKlines(interval: String, limit: Int): List<Candle> = withContext(Dispatchers.IO) {
        val url = "https://fapi.binance.com/fapi/v1/klines?symbol=BTCUSDT&interval=$interval&limit=$limit"
        val req=Request.Builder().url(url).build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) error("币安K线请求失败：HTTP ${res.code}")
            val a=JSONArray(res.body?.string() ?: "[]")
            (0 until a.length()).map { i -> val k=a.getJSONArray(i); val o=k.getString(1).toDouble(); val c=k.getString(4).toDouble(); Candle(o,k.getString(2).toDouble(),k.getString(3).toDouble(),c,k.getString(5).toDouble(),if(o==0.0) 0.0 else (c-o)/o*100) }
        }
    }
    private suspend fun fetchExtraMarketData(): String = withContext(Dispatchers.IO) {
        fun getJson(path: String): JSONObject {
            val req = Request.Builder().url("https://fapi.binance.com$path").build()
            client.newCall(req).execute().use { res -> if (!res.isSuccessful) error("HTTP ${res.code}"); JSONObject(res.body?.string() ?: "{}") }
        }
        val premium = getJson("/fapi/v1/premiumIndex?symbol=BTCUSDT")
        val oi = getJson("/fapi/v1/openInterest?symbol=BTCUSDT")
        val depthReq = Request.Builder().url("https://fapi.binance.com/fapi/v1/depth?symbol=BTCUSDT&limit=20").build()
        val depth = client.newCall(depthReq).execute().use { res -> if (!res.isSuccessful) error("HTTP ${res.code}"); JSONObject(res.body?.string() ?: "{}") }
        fun sumSide(key: String): Double { val a=depth.optJSONArray(key) ?: JSONArray(); var total=0.0; for(i in 0 until a.length()) total += a.getJSONArray(i).optString(1).toDoubleOrNull() ?: 0.0; return total }
        val bid=sumSide("bids"); val ask=sumSide("asks")
        "fundingRate=${premium.optString("lastFundingRate")}, markPrice=${premium.optString("markPrice")}, indexPrice=${premium.optString("indexPrice")}, openInterest=${oi.optString("openInterest")}, top20BidQty=$bid, top20AskQty=$ask, bidAskQtyRatio=${if(ask>0) bid/ask else 0.0}"
    }

    private fun buildMarketSummary(one: List<Candle>, five: List<Candle>, fifteen: List<Candle>, horizon: Int): String {
        fun series(name: String, xs: List<Candle>): String {
            val closes=xs.map { it.close }; val last=closes.last(); val prev=closes.getOrElse(closes.size-2){last}
            val emaFast=ema(closes, minOf(5, closes.size)); val emaSlow=ema(closes, minOf(12, closes.size))
            val gains=closes.zipWithNext().map { (a,b) -> b-a }
            val up=gains.filter { it>0 }.sum(); val down=abs(gains.filter { it<0 }.sum()).coerceAtLeast(0.000001)
            val rsi=100-100/(1+up/down)
            val avgVol=xs.dropLast(1).takeLast(5).map { it.volume }.average().takeIf { it.isFinite() && it>0 } ?: 1.0
            return "$name: close=$last, lastChangePct=${(last-prev)/prev*100}, EMAfast=$emaFast, EMAslow=$emaSlow, RSI14approx=$rsi, lastVolume=${xs.last().volume}, volumeVsRecentAvg=${xs.last().volume/avgVol}, recentCandles=" + xs.takeLast(if(horizon==10) 3 else 10).joinToString(";") { "O${it.open},H${it.high},L${it.low},C${it.close},V${it.volume}" }
        }
        return "BTCUSDT perpetual market data. Prediction horizon=$horizon minutes. Current websocket mark price=${SignalStore.price.value}.\n" + series("1m",one) + "\n" + series("5m",five) + "\n" + series("15m",fifteen) + "\nLatest kline may still be forming. Funding/open-interest/order-book values are point-in-time snapshots, not directional guarantees."
    }
    private fun ema(xs: List<Double>, period: Int): Double { val k=2.0/(period+1); return xs.drop(1).fold(xs.first()) { acc,v -> v*k+acc*(1-k) } }

    private suspend fun askAi(endpoint: String, model: String, key: String, horizon: Int, market: String): JSONObject = withContext(Dispatchers.IO) {
        val prompt = "你是严谨的BTC短线量化分析助手。根据提供的真实行情数据判断未来${horizon}分钟方向。结合多周期K线、趋势、EMA、RSI近似值、成交量变化、动量、波动和指标冲突。不可编造未提供的数据，不可保证盈利。若证据不足、方向冲突或风险过高，必须输出观望。只有多项证据一致时才允许方向为看涨或看跌，confidence至少75才算强信号。注意这是概率判断，不是事实。只输出JSON：{\"direction\":\"看涨|看跌|观望\",\"confidence\":0到100整数,\"reason\":\"简体中文简要说明证据和主要风险\"}。行情数据：\n$market"
        val body=JSONObject().put("model",model).put("temperature",0.1).put("response_format",JSONObject().put("type","json_object")).put("messages",JSONArray().put(JSONObject().put("role","system").put("content","你是谨慎的金融市场分析模型。严格使用输入数据，不得虚构。" )).put(JSONObject().put("role","user").put("content",prompt)))
        val req=Request.Builder().url(endpoint).header("Authorization","Bearer $key").post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { res ->
            val raw=res.body?.string().orEmpty(); if(!res.isSuccessful) error("AI接口返回HTTP ${res.code}: ${raw.take(180)}")
            val content=JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            JSONObject(content.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
        }
    }
    private suspend fun snapshotLoop() {
        while (currentCoroutineContext().isActive) {
            val px=SignalStore.price.value
            if (px>0 && SignalStore.connected.value) SignalStore.updatePrice(this@MarketService,System.currentTimeMillis(),px)
            delay(5_000)
        }
    }
}
