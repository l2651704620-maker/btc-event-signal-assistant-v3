package com.example.btcassistant.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class PredictionRecord(
    val id: Long, val horizon: Int, val side: String, val entry: Double,
    val createdAt: Long, val settleAt: Long, val confidence: Int,
    val reason: String, val snapshot: Double? = null, val result: String = "待结算"
)

object SignalStore {
    private const val PREF = "btc_v5_store"
    private const val KEY = "predictions"
    private val _price = MutableStateFlow(0.0)
    val price = _price.asStateFlow()
    private val _connected = MutableStateFlow(false)
    val connected = _connected.asStateFlow()
    private val _predictions = MutableStateFlow<List<PredictionRecord>>(emptyList())
    val predictions = _predictions.asStateFlow()
    private val _status10 = MutableStateFlow("尚未启动")
    val status10 = _status10.asStateFlow()
    private val _status30 = MutableStateFlow("尚未启动")
    val status30 = _status30.asStateFlow()
    private val _aiConfigured = MutableStateFlow(false)
    val aiConfigured = _aiConfigured.asStateFlow()

    fun setPrice(v: Double) { if (v > 0) _price.value = v }
    fun setConnected(v: Boolean) { _connected.value = v }
    fun setStatus(horizon: Int, value: String) { if (horizon == 10) _status10.value = value else _status30.value = value }
    fun setAiConfigured(v: Boolean) { _aiConfigured.value = v }

    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        _aiConfigured.value = prefs.getString("ai_key", "").orEmpty().isNotBlank()
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw); val list = mutableListOf<PredictionRecord>()
        for (i in 0 until arr.length()) runCatching {
            val o = arr.getJSONObject(i)
            list += PredictionRecord(o.getLong("id"), o.getInt("horizon"), o.getString("side"), o.getDouble("entry"), o.getLong("createdAt"), o.getLong("settleAt"), o.optInt("confidence"), o.optString("reason"), o.optNullableDouble("snapshot"), o.optString("result", "待结算"))
        }
        _predictions.value = list.sortedByDescending { it.createdAt }
    }
    fun saveAiConfig(context: Context, endpoint: String, model: String, key: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("ai_endpoint", endpoint.trim()).putString("ai_model", model.trim()).putString("ai_key", key.trim()).apply()
        _aiConfigured.value = key.isNotBlank()
    }
    fun aiConfig(context: Context): Triple<String, String, String> {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return Triple(p.getString("ai_endpoint", "https://api.openai.com/v1/chat/completions") ?: "https://api.openai.com/v1/chat/completions", p.getString("ai_model", "gpt-4o-mini") ?: "gpt-4o-mini", p.getString("ai_key", "") ?: "")
    }
    fun add(context: Context, r: PredictionRecord) { _predictions.value = (listOf(r) + _predictions.value).take(500); save(context) }
    fun updatePrice(context: Context, now: Long, price: Double) {
        val before = _predictions.value
        val after = before.map { r ->
            if (r.result != "待结算" || now < r.settleAt) r else {
                val win = if (r.side == "看涨") price > r.entry else price < r.entry
                r.copy(snapshot = price, result = if (win) "正确" else if (price == r.entry) "持平" else "错误")
            }
        }
        if (after != before) { _predictions.value = after; save(context) }
    }
    fun hasPending(horizon: Int): Boolean = _predictions.value.any { it.horizon == horizon && it.result == "待结算" }
    private fun save(c: Context) {
        val a = JSONArray(); _predictions.value.forEach { r ->
            val o = JSONObject().put("id",r.id).put("horizon",r.horizon).put("side",r.side).put("entry",r.entry).put("createdAt",r.createdAt).put("settleAt",r.settleAt).put("confidence",r.confidence).put("reason",r.reason).put("result",r.result)
            if (r.snapshot != null) o.put("snapshot",r.snapshot)
            a.put(o)
        }
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply()
    }
    private fun JSONObject.optNullableDouble(k: String): Double? = if (has(k) && !isNull(k)) optDouble(k) else null
}
