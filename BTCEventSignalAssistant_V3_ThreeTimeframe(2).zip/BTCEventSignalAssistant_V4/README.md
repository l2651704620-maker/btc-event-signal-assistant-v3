# BTC Signal Assistant V5

A standalone Android app for BTCUSDT perpetual market monitoring. It does not place trades.

## Two independent AI prediction modules

- **10-minute module:** when manually started, reads recent 1-minute candles (including the latest ~3-minute movement), plus 5m/15m context, indicators and derivatives/order-book snapshots; asks the configured AI endpoint to assess the next 10 minutes.
- **30-minute module:** when manually started, reads recent 10-minute 1m-candle movement plus 5m/15m context and the same extra market data; asks the AI endpoint to assess the next 30 minutes.
- Both modules are independent. Only a clear bullish/bearish answer with AI confidence >= 75 is recorded. Otherwise the app reports that no strong signal was issued.
- Each prediction locks the start-time mark price and timestamp. At the end of its horizon, the app snapshots the Binance mark price and settles the record automatically.
- Records and results are stored locally on the phone.

## AI configuration required

Open **AI设置** in the app and enter:

1. An OpenAI Chat Completions-compatible endpoint URL.
2. A model name supported by that provider.
3. Your own API key.

The default endpoint is `https://api.openai.com/v1/chat/completions` and the default model field is `gpt-4o-mini`; change either if your provider requires different values. The app does not contain a bundled API key. Without a key, AI prediction buttons remain disabled and no AI result is fabricated.

**Security note:** this starter implementation stores the API key in the app's private SharedPreferences on the phone. It is not embedded in the APK, but a dedicated backend proxy with server-side secret storage is safer for production use. Do not use a key with broad permissions or share the APK with your key configured.

## Market data

- Binance USDⓈ-M Futures mark-price WebSocket for live BTCUSDT price.
- Binance public futures klines for 1m, 5m and 15m candles.
- Binance public funding-rate/mark/index-price, open-interest and order-book depth snapshots.
- No Binance trading API key is requested; no order-placement code is included.

## Build

Use Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, Android SDK 35. Run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds this project and uploads the debug APK as an artifact.

## Important

Signals are probabilistic research outputs, not financial advice or guarantees. The AI confidence field is model-reported and must not be interpreted as a calibrated probability. Validate with paper trading and historical tests before risking money. The app is manual-confirmation only and never trades automatically.
