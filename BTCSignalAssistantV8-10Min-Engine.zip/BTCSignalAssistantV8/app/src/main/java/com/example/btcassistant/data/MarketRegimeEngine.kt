package com.example.btcassistant.data

import kotlin.math.abs
import kotlin.math.max

/**
 * Short-horizon market-state classifier. It uses closed candles only and reports a
 * descriptive regime, not a probability. Thresholds are intentionally conservative.
 */
data class MarketRegimeAssessment(
    val label: String,
    val trendStrength: Double,
    val volatilityPercent: Double,
    val volatilityExpansion: Double,
    val direction: Int,
    val confidence: Int,
    val detail: String
)

object MarketRegimeEngine {
    fun classify(
        oneMinute: List<StrategyCandle>,
        threeMinute: List<StrategyCandle>,
        fiveMinute: List<StrategyCandle>,
        fifteenMinute: List<StrategyCandle>
    ): MarketRegimeAssessment {
        require(oneMinute.size >= 35 && threeMinute.size >= 20 && fiveMinute.size >= 20 && fifteenMinute.size >= 12) {
            "市场状态识别样本不足"
        }
        val last = oneMinute.last()
        val five = fiveMinute.last()
        val atr1 = atr(oneMinute, 14).coerceAtLeast(last.close * 0.00001)
        val atr5 = atr(fiveMinute, 14).coerceAtLeast(five.close * 0.00001)
        val atrPercent = atr1 / last.close * 100.0
        val atrHistory = (14..minOf(55, oneMinute.size - 1)).mapNotNull { offset ->
            val end = oneMinute.size - offset
            if (end >= 15) atr(oneMinute.take(end), 14) else null
        }
        val baselineAtr = atrHistory.average().takeIf { it.isFinite() && it > 0.0 } ?: atr1
        val expansion = atr1 / baselineAtr.coerceAtLeast(last.close * 0.00001)

        val adx5 = adx(fiveMinute, 14)
        val emaFast = ema(fiveMinute.map { it.close }, 9)
        val emaSlow = ema(fiveMinute.map { it.close }, 21)
        val emaSpread = abs(emaFast - emaSlow) / atr5
        val dir5 = slopeDirection(fiveMinute.map { it.close }, 4)
        val dir15 = slopeDirection(fifteenMinute.map { it.close }, 3)
        val dir3 = slopeDirection(threeMinute.map { it.close }, 4)
        val aligned = dir5 != 0 && dir5 == dir15
        val prior = fiveMinute.dropLast(1).takeLast(12)
        val breakUp = prior.size >= 10 && five.close > prior.maxOf { it.high }
        val breakDown = prior.size >= 10 && five.close < prior.minOf { it.low }
        val avgVolume = prior.map { it.volume }.average().coerceAtLeast(1e-12)
        val volumeRatio = five.volume / avgVolume
        val confirmedBreak = (breakUp || breakDown) && volumeRatio >= 1.15

        val highVolatility = atrPercent >= 0.18 || expansion >= 1.85
        val direction = when {
            breakUp -> 1
            breakDown -> -1
            aligned -> dir5
            dir5 != 0 && dir3 == dir5 -> dir5
            else -> 0
        }
        val label = when {
            highVolatility -> "高波动"
            confirmedBreak && breakUp -> "突破上涨"
            confirmedBreak && breakDown -> "突破下跌"
            adx5 >= 21.0 && emaSpread >= 0.28 && aligned && dir5 > 0 -> "趋势上涨"
            adx5 >= 21.0 && emaSpread >= 0.28 && aligned && dir5 < 0 -> "趋势下跌"
            adx5 < 17.0 && emaSpread < 0.22 && !confirmedBreak -> "震荡"
            else -> "方向切换"
        }
        val strength = (adx5 * 0.65 + (emaSpread * 35.0).coerceAtMost(25.0) + if (aligned) 10.0 else 0.0).coerceIn(0.0, 100.0)
        val confidence = when {
            label == "高波动" -> 80
            label.startsWith("突破") -> if (volumeRatio >= 1.5) 82 else 68
            label.startsWith("趋势") -> (55 + strength * 0.35).toInt().coerceIn(55, 88)
            label == "震荡" -> 72
            else -> 50
        }
        val volatilityLabel = when {
            highVolatility -> "异常扩张"
            expansion >= 1.30 -> "波动放大"
            expansion <= 0.75 -> "波动收缩"
            else -> "波动正常"
        }
        val detail = "状态=$label；5m ADX=${"%.1f".format(adx5)}；EMA差/ATR=${"%.2f".format(emaSpread)}；趋势方向5m=${side(dir5)}、15m=${side(dir15)}、3m=${side(dir3)}；1m ATR=${"%.3f".format(atrPercent)}%；波动扩张=${"%.2f".format(expansion)}倍（$volatilityLabel）；5m突破量能=${"%.2f".format(volumeRatio)}倍；状态识别参考强度=${strength.toInt()}/100"
        return MarketRegimeAssessment(label, strength, atrPercent, expansion, direction, confidence, detail)
    }

    private fun side(value: Int) = when (value) { 1 -> "偏多"; -1 -> "偏空"; else -> "中性" }
    private fun slopeDirection(values: List<Double>, bars: Int): Int {
        if (values.size <= bars) return 0
        val delta = values.last() - values[values.lastIndex - bars]
        val scale = values.last().coerceAtLeast(1e-9)
        return when { delta / scale > 0.00008 -> 1; delta / scale < -0.00008 -> -1; else -> 0 }
    }
    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1.0)
        var result = values.first()
        values.drop(1).forEach { result = it * k + result * (1.0 - k) }
        return result
    }
    private fun atr(xs: List<StrategyCandle>, period: Int): Double {
        if (xs.size < period + 1) return xs.last().high - xs.last().low
        return xs.takeLast(period + 1).drop(1).mapIndexed { i, c ->
            val previous = xs[xs.size - period - 1 + i].close
            max(c.high - c.low, max(abs(c.high - previous), abs(c.low - previous)))
        }.average()
    }
    private fun adx(xs: List<StrategyCandle>, period: Int): Double {
        if (xs.size < period * 2 + 1) return 0.0
        val rows = xs.takeLast(period * 2 + 1)
        val plus = mutableListOf<Double>(); val minus = mutableListOf<Double>(); val ranges = mutableListOf<Double>()
        for (i in 1 until rows.size) {
            val a = rows[i - 1]; val b = rows[i]
            val up = b.high - a.high; val down = a.low - b.low
            plus += if (up > down && up > 0) up else 0.0
            minus += if (down > up && down > 0) down else 0.0
            ranges += max(b.high - b.low, max(abs(b.high - a.close), abs(b.low - a.close)))
        }
        val dx = plus.indices.map { i ->
            val tr = ranges[i].coerceAtLeast(1e-12)
            val p = plus[i] / tr * 100.0; val m = minus[i] / tr * 100.0
            abs(p - m) / (p + m).coerceAtLeast(1e-12) * 100.0
        }
        return dx.takeLast(period).average().coerceIn(0.0, 100.0)
    }
}
