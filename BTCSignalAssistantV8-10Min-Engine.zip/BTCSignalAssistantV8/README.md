# BTC Signal Assistant V8 — 10-minute edition

Android BTC/USDT spot + USDT perpetual market signal assistant. Human-confirmed signals only; it does not place orders.

## V8 focus
- The app now exposes a single prediction horizon: the next 10 minutes. The 30-minute prediction button, service action, signal status, chart interval, and 30-minute backtest path have been removed.
- Reworked direction engine: 1m execution/momentum, locally aggregated 3m structure, 5m primary confirmation, 15m trend context, and a light 1h background filter. The last 1m candle no longer overrides the multi-timeframe vote.
- Added explicit trend-agreement and momentum-agreement diagnostics, anti-chase stretch checks, low-volume warnings, and short-term exhaustion checks.
- Direction display rule: low/medium risk preserves the raw direction; high risk reverses the displayed direction. Raw direction and final direction are stored separately for review.
- Retains Binance spot + USDT perpetual data, Elliott-wave structure, technical knowledge modules, adaptive learning with held-out validation, snapshot settlement, and the existing faster chart refresh path.
- Historical backtest is now 10-minute only with chronological development/validation/out-of-sample splits and fee/slippage assumptions.

## Important data limits
- Liquidation/forced-order stream is not connected; the app must not infer or fabricate liquidation values.
- Order-book imbalance is a snapshot, not spoofing-resistant full-depth flow; stale derivatives snapshots are excluded from the vote.
- VWAP is a rolling 20-candle approximation, OBV is a candle-volume proxy (not trade-level CVD), and no liquidation stream is connected.
- The displayed score is a rule-match score, not a calibrated win probability or a guarantee of profit.
- 10-minute BTC direction is noisy. Compare out-of-sample results and maintain enough samples before changing live strategy weights.

## Build
Use JDK 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## V8.1 short-horizon refinements
- Fixed signed-distance support/resistance checks that could misclassify prices beyond a level as "near".
- Conflicting candle-pattern evidence now produces a neutral module vote instead of an arbitrary bullish-first result.
- Knowledge votes are reduced in the fusion layer where they overlap with standalone momentum indicators.
- Neutral vote tie-breaking now uses observed recent momentum rather than an unconditional bullish default.
- Only high-risk signals reverse direction; medium-risk signals retain the raw direction.
- Futures sentiment votes are ignored when the derivatives snapshot is older than 90 seconds.
- Reduced the 10m chart polling frequency to 15 seconds because its bars are built from closed 1m candles; the live ticker remains independently updated by WebSocket.\n

## V8.2 市场状态识别升级

新增 `MarketRegimeEngine`，仅使用已收盘的 1m/3m/5m/15m K 线识别：趋势上涨、趋势下跌、震荡、突破上涨、突破下跌、方向切换及高波动。判断依据包括 5m ADX、EMA 差值相对 ATR、多周期方向一致性、12 根 5m K 线区间突破与成交量确认，以及 1m ATR 波动扩张。

市场状态用于动态调整趋势与突破投票权重；震荡状态会适度降低趋势追随权重，并仅在 RSI 与 VWAP 偏离同时达到条件时加入均值回归修正。高波动状态会加入风险提示。状态识别强度不是胜率概率，阈值仍需通过历史样本和模拟信号验证。


## V8.3 策略验证闭环升级

本次借鉴 Crypto Lab 的策略模块化与回测思路、btcBeep 的信号表达、Crypto Signals 的信号追踪、TradingView 的历史验证方式，以及 CoinGlass 的衍生品数据观察维度；仅借鉴分析理念，不代表接入这些第三方软件或其私有数据。

- 自主学习从单一艾略特波浪扩展为艾略特波浪、Raschke、Wyckoff 三个独立模块，按 10 分钟周期与市场状态分组统计。
- 每个市场状态内按时间先后切分训练集与验证集，至少 20 个训练样本、12 个验证样本，验证胜率至少 55% 且高于验证集整体基准 5 个百分点，才允许该模块获得 1.15 倍轻量权重。
- 验证权重只作用于对应模块投票；未通过验证的模块保持基准权重，不会因训练集表现好而直接上线。
- 分析理由会显示哪些学习模块已通过独立验证。评分仍是规则匹配度，不等于胜率概率。
