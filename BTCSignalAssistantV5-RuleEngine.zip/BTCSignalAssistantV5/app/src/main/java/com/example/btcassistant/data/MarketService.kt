package com.example.btcassistant.data

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/** Multi-exchange BTC spot feed. A socket is considered healthy only after a real price tick. */
class MarketService : Service() {
    companion object {
        const val ACTION_PREDICT_10 = "com.example.btcassistant.PREDICT_10"
        const val ACTION_PREDICT_30 = "com.example.btcassistant.PREDICT_30"
        private const val STALE_MS = 15_000L
    }
    private data class Tick(val price: Double, val at: Long)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient.Builder().connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS).callTimeout(25, TimeUnit.SECONDS).build()
    private val wsClient = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS)
        .connectTimeout(12, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()
    private val sockets = ConcurrentHashMap<String, WebSocket>()
    private val reconnecting = ConcurrentHashMap<String, Boolean>()
    private val ticks = ConcurrentHashMap<String, Tick>()
    private val socketOpenedAt = ConcurrentHashMap<String, Long>()
    private val retry = ConcurrentHashMap<String, Long>()
    private var predicting10 = false
    private var predicting30 = false

    override fun onCreate() {
        super.onCreate(); SignalStore.load(this)
        startForeground(51, notification("正在连接多平台 BTC 行情"))
        connectAll()
        scope.launch { marketWatchdog() }
        scope.launch { snapshotLoop() }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PREDICT_10 -> if (!predicting10) scope.launch { runPrediction(10) }
            ACTION_PREDICT_30 -> if (!predicting30) scope.launch { runPrediction(30) }
        }
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { sockets.values.forEach { it.close(1000, "service stopped") }; sockets.clear(); scope.cancel(); super.onDestroy() }

    private fun notification(s: String): Notification {
        val channel = "btc_market_v5"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"BTC行情监控",NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this,channel).setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("BTC信号助手 V5").setContentText(s).setOngoing(true).build()
    }
    private fun updateNotification(s: String) { if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).notify(51,notification(s)) }

    private fun connectAll() {
        connect("Binance", "wss://stream.binance.com:9443/ws/btcusdt@trade")
        connect("OKX", "wss://ws.okx.com:8443/ws/v5/public", JSONObject().put("op","subscribe").put("args",JSONArray().put(JSONObject().put("channel","tickers").put("instId","BTC-USDT"))).toString())
        connect("Bybit", "wss://stream.bybit.com/v5/public/spot", JSONObject().put("op","subscribe").put("args",JSONArray().put("tickers.BTCUSDT")).toString())
    }
    private fun connect(name: String, url: String, subscribe: String? = null) {
        if (sockets.containsKey(name)) return
        val request = Request.Builder().url(url).build()
        val ws = wsClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                socketOpenedAt[name] = System.currentTimeMillis()
                retry[name] = 2L
                if (subscribe != null) webSocket.send(subscribe)
                SignalStore.setMarketStatus("已建立${name}通道，等待真实行情数据")
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching {
                    val root = JSONObject(text)
                    val price: Double
                    val ts: Long
                    when (name) {
                        "Binance" -> { price = root.optString("p").toDouble(); ts = root.optLong("T", System.currentTimeMillis()) }
                        "OKX" -> { val item = root.optJSONArray("data")?.optJSONObject(0) ?: return; price = item.optString("last").toDouble(); ts = item.optString("ts").toLongOrNull() ?: System.currentTimeMillis() }
                        else -> { val item = root.optJSONObject("data") ?: return; price = item.optString("lastPrice").toDouble(); ts = root.optLong("ts", System.currentTimeMillis()) }
                    }
                    if (price.isFinite() && price in 1_000.0..10_000_000.0) onTick(name, price, ts)
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                sockets.remove(name, webSocket); socketOpenedAt.remove(name); scheduleReconnect(name, url, subscribe, t.message ?: "网络错误")
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                sockets.remove(name, webSocket); socketOpenedAt.remove(name); scheduleReconnect(name, url, subscribe, "连接关闭($code)")
            }
        })
        sockets[name] = ws
    }
    private fun scheduleReconnect(name: String, url: String, subscribe: String?, reason: String) {
        SignalStore.setMarketStatus("${name}连接中断：$reason，正在自动重连")
        if (reconnecting.putIfAbsent(name, true) == true) return
        scope.launch {
            val wait = retry[name] ?: 2L
            delay(wait * 1000)
            retry[name] = (wait * 2).coerceAtMost(60)
            reconnecting.remove(name)
            if (sockets[name] == null) connect(name, url, subscribe)
        }
    }
    private fun onTick(source: String, price: Double, exchangeTime: Long) {
        val now = System.currentTimeMillis()
        // Exchange timestamps can drift; receipt time is used for freshness, exchange time is retained only as metadata.
        ticks[source] = Tick(price, now)
        val fresh = ticks.filterValues { now - it.at <= STALE_MS }
        if (fresh.isEmpty()) return
        val sorted = fresh.values.map { it.price }.sorted()
        val median = if (sorted.size % 2 == 1) sorted[sorted.size / 2] else (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
        val spreadPct = if (median > 0) (sorted.last() - sorted.first()) / median * 100 else 100.0
        // Reject a wildly divergent venue; with two feeds use their midpoint only if close enough.
        val accepted = fresh.filterValues { abs(it.price - median) / median * 100 <= 0.35 }
        if (accepted.isEmpty()) return
        val acceptedPrices = accepted.values.map { it.price }.sorted()
        val consensus = if (acceptedPrices.size % 2 == 1) acceptedPrices[acceptedPrices.size / 2] else acceptedPrices.average()
        SignalStore.setPrice(consensus)
        SignalStore.setMarketHealth(true, accepted.keys.sorted().joinToString(" + "), now, accepted.size, spreadPct)
    }
    private suspend fun marketWatchdog() {
        while (currentCoroutineContext().isActive) {
            val now = System.currentTimeMillis()
            // A successful WebSocket handshake without actual price ticks is NOT a healthy feed.
            for (name in listOf("Binance", "OKX", "Bybit")) {
                val lastActivity = ticks[name]?.at ?: socketOpenedAt[name] ?: now
                if (sockets.containsKey(name) && now - lastActivity > STALE_MS) {
                    val staleSocket = sockets.remove(name)
                    staleSocket?.close(4000, "no market ticks")
                    val endpoint = when (name) {
                        "Binance" -> "wss://stream.binance.com:9443/ws/btcusdt@trade"
                        "OKX" -> "wss://ws.okx.com:8443/ws/v5/public"
                        else -> "wss://stream.bybit.com/v5/public/spot"
                    }
                    val sub = when (name) {
                        "OKX" -> JSONObject().put("op","subscribe").put("args",JSONArray().put(JSONObject().put("channel","tickers").put("instId","BTC-USDT"))).toString()
                        "Bybit" -> JSONObject().put("op","subscribe").put("args",JSONArray().put("tickers.BTCUSDT")).toString()
                        else -> null
                    }
                    scheduleReconnect(name, endpoint, sub, "超过15秒没有收到价格推送")
                }
            }
            val fresh = ticks.filterValues { now - it.at <= STALE_MS }
            if (fresh.isEmpty()) {
                SignalStore.setMarketHealth(false, "无有效数据", 0L, 0, 0.0)
                SignalStore.setMarketStatus("未收到实时行情数据，正在连接/重连 Binance、OKX、Bybit")
            } else {
                val prices = fresh.values.map { it.price }.sorted()
                val med = if (prices.size % 2 == 1) prices[prices.size / 2] else (prices[prices.size / 2 - 1] + prices[prices.size / 2]) / 2.0
                val accepted = fresh.filterValues { abs(it.price - med) / med * 100 <= 0.35 }
                val acceptedPrices = accepted.values.map { it.price }.sorted()
                val spread = if (acceptedPrices.size > 1 && med > 0) (acceptedPrices.last() - acceptedPrices.first()) / med * 100 else 0.0
                SignalStore.setMarketHealth(accepted.isNotEmpty(), accepted.keys.sorted().joinToString(" + ").ifEmpty { "价格分歧过大" }, accepted.values.maxOfOrNull { it.at } ?: 0L, accepted.size, spread)
                SignalStore.setMarketStatus(when { accepted.size >= 2 -> "多平台实时行情正常（${accepted.size}路）"; accepted.size == 1 -> "仅${accepted.keys.first()}有一致性行情，等待第二数据源"; else -> "多平台价格分歧过大，暂停分析" })
            }
            delay(3_000)
        }
    }

    private suspend fun runPrediction(horizon: Int) {
        if (horizon == 10) predicting10 = true else predicting30 = true
        SignalStore.setStatus(horizon, "正在读取实时行情并运行量化规则…")
        val requestedAt = System.currentTimeMillis()
        try {
            if (SignalStore.hasPending(horizon)) { SignalStore.setStatus(horizon, "上一笔预测尚未结算，请稍后再启动"); return }
            val freshCount = SignalStore.activeFeeds.value
            if (SignalStore.price.value <= 0 || !SignalStore.connected.value) error("尚未收到有效实时行情，请检查网络连接")
            if (freshCount < 2) error("多平台模式需要至少2个交易所同时提供新鲜行情；当前只有${freshCount}路有效数据")
            val referencePrice = SignalStore.price.value
            val oneMin = fetchKlines("1m", 40)
            val fiveMin = fetchKlines("5m", 35)
            val fifteenMin = fetchKlines("15m", 24)
            val result = evaluateRules(oneMin, fiveMin, fifteenMin, horizon)
            if (!SignalStore.connected.value || SignalStore.activeFeeds.value < 2 || System.currentTimeMillis()-SignalStore.lastMarketUpdate.value > STALE_MS) {
                error("分析期间多平台实时行情失效，已取消本次信号")
            }
            val side = result.direction
            if (side == "观望") {
                SignalStore.setStatus(horizon, "规则评分不足或多周期冲突：${result.reason}；本次观望，不生成预测")
            } else {
                SignalStore.add(this, PredictionRecord(requestedAt, horizon, side, referencePrice, requestedAt,
                    requestedAt + horizon*60_000L, result.confidence,
                    "规则引擎 ${result.score}/100：${result.reason}（行情源：${SignalStore.marketSource.value}）"))
                SignalStore.setStatus(horizon, "已生成${side}信号 · 规则评分${result.score}/100 · ${horizon}分钟后自动结算")
                updateNotification("${horizon}分钟规则信号：$side，请人工确认")
            }
        } catch (e: Exception) { SignalStore.setStatus(horizon, "分析失败：${e.message ?: "行情或网络异常"}") }
        finally { if (horizon == 10) predicting10 = false else predicting30 = false }
    }

    private data class Candle(val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
    private suspend fun fetchKlines(interval: String, limit: Int): List<Candle> = withContext(Dispatchers.IO) {
        val errors = mutableListOf<String>()
        // The first available exchange is used for each timeframe; all URLs are public market-data endpoints.
        val paths = listOf(
            "Binance" to "https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=$interval&limit=$limit",
            "OKX" to "https://www.okx.com/api/v5/market/candles?instId=BTC-USDT&bar=$interval&limit=$limit",
            "Bybit" to "https://api.bybit.com/v5/market/kline?category=spot&symbol=BTCUSDT&interval=${intervalToBybit(interval)}&limit=$limit"
        )
        for ((venue,url) in paths) try {
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) error("HTTP ${res.code}")
                val body = res.body?.string().orEmpty()
                val rows: List<Candle> = when (venue) {
                    "Binance" -> { val a=JSONArray(body); (0 until a.length()).map { i -> val k=a.getJSONArray(i); Candle(k.getString(1).toDouble(),k.getString(2).toDouble(),k.getString(3).toDouble(),k.getString(4).toDouble(),k.getString(5).toDouble()) } }
                    "OKX" -> { val a=JSONObject(body).getJSONArray("data"); (0 until a.length()).map { i -> val k=a.getJSONArray(i); Candle(k.getString(1).toDouble(),k.getString(2).toDouble(),k.getString(3).toDouble(),k.getString(4).toDouble(),k.getString(5).toDouble()) }.reversed() }
                    else -> { val a=JSONObject(body).getJSONObject("result").getJSONArray("list"); (0 until a.length()).map { i -> val k=a.getJSONArray(i); Candle(k.getString(1).toDouble(),k.getString(2).toDouble(),k.getString(3).toDouble(),k.getString(4).toDouble(),k.getString(5).toDouble()) }.reversed() }
                }
                if (rows.size < 3) error("K线数量不足")
                return@withContext rows
            }
        } catch (e: Exception) { errors += "$venue:${e.message}" }
        error("所有交易所K线接口均不可用（${errors.joinToString("；")}）")
    }
    private fun intervalToBybit(interval: String) = when(interval) { "1m" -> "1"; "5m" -> "5"; "15m" -> "15"; else -> "1" }

    private suspend fun fetchExtraMarketData(): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=BTCUSDT").build()
        client.newCall(req).execute().use { res -> if (!res.isSuccessful) error("HTTP ${res.code}"); val p=JSONObject(res.body?.string().orEmpty()); "Binance fundingRate=${p.optString("lastFundingRate")}, markPrice=${p.optString("markPrice")}, indexPrice=${p.optString("indexPrice")}" }
    }
    private fun buildMarketSummary(one: List<Candle>, five: List<Candle>, fifteen: List<Candle>, horizon: Int): String {
        fun series(name: String, xs: List<Candle>): String {
            val closes=xs.map { it.close }; val last=closes.last(); val prev=closes.getOrElse(closes.size-2){last}
            val emaFast=ema(closes, minOf(5, closes.size)); val emaSlow=ema(closes, minOf(12, closes.size))
            val gains=closes.zipWithNext().map { (a,b) -> b-a }; val up=gains.filter { it>0 }.sum(); val down=abs(gains.filter { it<0 }.sum()).coerceAtLeast(0.000001)
            val rsi=100-100/(1+up/down); val avgVol=xs.dropLast(1).takeLast(5).map { it.volume }.average().takeIf { it.isFinite() && it>0 } ?: 1.0
            return "$name: close=$last, lastChangePct=${(last-prev)/prev*100}, EMAfast=$emaFast, EMAslow=$emaSlow, RSI14approx=$rsi, lastVolume=${xs.last().volume}, volumeVsRecentAvg=${xs.last().volume/avgVol}, recentCandles=" + xs.takeLast(if(horizon==10) 3 else 10).joinToString(";") { "O${it.open},H${it.high},L${it.low},C${it.close},V${it.volume}" }
        }
        return "BTCUSDT spot market data. Prediction horizon=$horizon minutes. Multi-exchange consensus price=${SignalStore.price.value}.\n" + series("1m",one) + "\n" + series("5m",five) + "\n" + series("15m",fifteen) + "\nKlines may be forming; cross-exchange tick consensus is used for live price."
    }
    private data class RuleResult(val direction: String, val score: Int, val confidence: Int, val reason: String)

    /** Deterministic rule engine inspired by public trend, breakout, volume/price and momentum frameworks. */
    private fun evaluateRules(one: List<Candle>, five: List<Candle>, fifteen: List<Candle>, horizon: Int): RuleResult {
        if (one.size < 20 || five.size < 20 || fifteen.size < 12) error("K线样本不足，暂不分析")
        var bull = 0.0
        var bear = 0.0
        val notes = mutableListOf<String>()
        fun award(up: Boolean, points: Double, note: String) {
            if (up) bull += points else bear += points
            notes += note
        }
        fun trend(xs: List<Candle>, label: String, weight: Double) {
            val closes = xs.map { it.close }
            val fast = ema(closes, 9); val slow = ema(closes, 21)
            val rising = closes.last() > closes[closes.size-4]
            if (fast > slow && rising) award(true, weight, "${label}短均线在长均线上方且动量向上")
            else if (fast < slow && !rising) award(false, weight, "${label}短均线在长均线下方且动量向下")
        }
        // Livermore-style: trade in the direction of a confirmed move through a recent pivot.
        val recent = one.takeLast(if (horizon == 10) 3 else 10)
        val prior = one.dropLast(recent.size).takeLast(12)
        val last = one.last()
        val priorHigh = prior.maxOf { it.high }; val priorLow = prior.minOf { it.low }
        if (last.close > priorHigh && last.volume > prior.map { it.volume }.average() * 1.15) award(true, 2.0, "放量突破近期关键高点")
        else if (last.close < priorLow && last.volume > prior.map { it.volume }.average() * 1.15) award(false, 2.0, "放量跌破近期关键低点")
        // Multi-timeframe trend alignment.
        trend(one, "1分钟", 1.0); trend(five, "5分钟", 2.0); trend(fifteen, "15分钟", 1.5)
        // RSI momentum, avoiding chasing extreme readings.
        val rsi = rsi(one.map { it.close }, 14)
        if (rsi in 52.0..68.0) award(true, 1.0, "RSI动量偏强但未进入极端区")
        else if (rsi in 32.0..48.0) award(false, 1.0, "RSI动量偏弱但未进入极端区")
        else if (rsi > 78 || rsi < 22) notes += "RSI处于极端区，追价风险增加"
        // Wyckoff-style effort versus result: volume confirmation and absorption warning.
        val avgVol = one.dropLast(1).takeLast(12).map { it.volume }.average().coerceAtLeast(0.000001)
        val volRatio = last.volume / avgVol
        val candleRange = ((last.high-last.low)/last.close*100).coerceAtLeast(0.0)
        val candleUp = last.close > last.open
        if (volRatio >= 1.25 && candleRange > 0.035) award(candleUp, 1.5, "成交量放大且价格有效推进")
        val absorption = volRatio >= 1.8 && candleRange < 0.025
        if (absorption) notes += "放量但价格推进有限，疑似供需吸收，降低信号强度"
        // VWAP-like volume-weighted reference over recent candles.
        val sample = one.takeLast(20)
        val totalVol = sample.sumOf { it.volume }.coerceAtLeast(0.000001)
        val vwap = sample.sumOf { ((it.high+it.low+it.close)/3.0)*it.volume } / totalVol
        if (last.close > vwap) award(true, 1.0, "价格位于短周期成交量加权均价上方")
        else award(false, 1.0, "价格位于短周期成交量加权均价下方")
        // Linda Raschke-inspired ADX regime filter: avoid weak/choppy and very strong counter-trend setups.
        val adx = adx(five, 14)
        val fiveFast = ema(five.map { it.close }, 9); val fiveSlow = ema(five.map { it.close }, 21)
        val fiveUp = fiveFast > fiveSlow
        val directionUp = bull > bear
        val trendConflict = (fifteen.last().close > ema(fifteen.map { it.close }, 9)) != fiveUp
        if (adx < 18.0) notes += "ADX=${"%.1f".format(adx)}，趋势强度偏低，震荡假信号风险高"
        if (adx > 35.0 && ((directionUp && !fiveUp) || (!directionUp && fiveUp))) notes += "ADX强趋势环境，不逆势追单"
        val margin = kotlin.math.abs(bull-bear)
        val rawScore = (50.0 + (bull-bear)*5.5).coerceIn(0.0, 100.0)
        val chosenUp = bull > bear
        val confidence = (55.0 + margin*4.0).coerceIn(0.0, 92.0).toInt()
        val hasMacroConflict = (chosenUp && fifteen.last().close < ema(fifteen.map { it.close }, 9)) || (!chosenUp && fifteen.last().close > ema(fifteen.map { it.close }, 9))
        val weakRegime = adx < 15.0
        val clear = margin >= 2.2 && confidence >= 68 && !hasMacroConflict && !weakRegime && !trendConflict && !absorption
        val direction = if (!clear) "观望" else if (chosenUp) "看涨" else "看跌"
        val score = if (direction == "观望") rawScore.toInt() else (50 + margin*5).coerceIn(0.0, 95.0).toInt()
        val summary = "多空分=${"%.1f".format(bull)}/${"%.1f".format(bear)}；ADX=${"%.1f".format(adx)}；RSI=${"%.1f".format(rsi)}；量能=${"%.2f".format(volRatio)}倍；" + notes.distinct().take(5).joinToString("；")
        return RuleResult(direction, score, confidence, summary)
    }

    private fun ema(xs: List<Double>, period: Int): Double {
        val k=2.0/(period+1)
        return xs.drop(1).fold(xs.first()) { acc,v -> v*k+acc*(1-k) }
    }
    private fun rsi(xs: List<Double>, period: Int): Double {
        val changes = xs.zipWithNext().takeLast(period).map { it.second-it.first }
        val up = changes.filter { it>0 }.sumOf { it }
        val down = abs(changes.filter { it<0 }.sum()).coerceAtLeast(0.000001)
        return 100.0 - 100.0/(1.0+up/down)
    }
    private fun adx(xs: List<Candle>, period: Int): Double {
        val rows = xs.takeLast(period+1)
        if (rows.size < 4) return 20.0
        var plus = 0.0; var minus = 0.0; var tr = 0.0
        for (i in 1 until rows.size) {
            val a=rows[i-1]; val b=rows[i]
            val up=b.high-a.high; val down=a.low-b.low
            if (up>down && up>0) plus += up
            if (down>up && down>0) minus += down
            tr += maxOf(b.high-b.low, abs(b.high-a.close), abs(b.low-a.close))
        }
        if (tr<=0) return 0.0
        val p=plus/tr*100; val m=minus/tr*100
        return (abs(p-m)/(p+m).coerceAtLeast(0.000001)*100).coerceIn(0.0, 100.0)
    }

    private suspend fun snapshotLoop() {
        while (currentCoroutineContext().isActive) {
            val px=SignalStore.price.value
            if (px>0 && SignalStore.connected.value && System.currentTimeMillis()-SignalStore.lastMarketUpdate.value <= STALE_MS) SignalStore.updatePrice(this@MarketService,System.currentTimeMillis(),px)
            delay(5_000)
        }
    }
}
