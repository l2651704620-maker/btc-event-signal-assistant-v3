package com.example.btcassistant.data

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Closed exchange candle used by the deterministic three-strategy engine. */
data class StrategyCandle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class ModuleSignal(val direction: Int, val strength: Double, val detail: String) {
    // direction: +1 bullish, -1 bearish, 0 neutral. Strength is a rule score, not probability.
}

data class FusionResult(
    val direction: String,
    val score: Int,
    val confidence: Int,
    val reason: String,
    val gann: ModuleSignal,
    val raschke: ModuleSignal,
    val wyckoff: ModuleSignal
)

/**
 * Rule-based adaptations of public Gann, Linda Raschke and Wyckoff concepts.
 * These are experimental, testable approximations, not a claim to reproduce any trader's private system.
 */
object FusionStrategyEngine {
    fun evaluate(
        oneMinute: List<StrategyCandle>,
        fiveMinute: List<StrategyCandle>,
        fifteenMinute: List<StrategyCandle>,
        oneHour: List<StrategyCandle>,
        horizonMinutes: Int
    ): FusionResult {
        val primary = if (horizonMinutes == 10) oneMinute else fiveMinute
        val context = if (horizonMinutes == 10) fiveMinute else fifteenMinute
        val macro = if (horizonMinutes == 10) fifteenMinute else oneHour
        require(primary.size >= 80 && context.size >= 40 && macro.size >= 50) { "历史K线不足：需要主周期80根、辅助周期40根、大周期50根已收盘K线" }
        val gann = gann(primary)
        val raschke = raschke(primary, context, horizonMinutes)
        val wyckoff = wyckoff(primary)
        val weights = if (horizonMinutes == 10) doubleArrayOf(0.20, 0.45, 0.35) else doubleArrayOf(0.25, 0.35, 0.40)
        val modules = listOf(gann, raschke, wyckoff)
        val weighted = modules.indices.sumOf { modules[it].direction * (modules[it].strength / 100.0) * weights[it] }
        val activeAligned = modules.count { it.direction != 0 && it.direction == (if (weighted >= 0) 1 else -1) }
        val strongOpposition = modules.any { it.direction != 0 && it.direction != (if (weighted >= 0) 1 else -1) && it.strength >= 75.0 }
        val macroTrend = ema(macro.map { it.close }, 20) - ema(macro.map { it.close }, 50)
        val macroConflict = (weighted > 0 && macroTrend < 0) || (weighted < 0 && macroTrend > 0)
        val side = if (weighted > 0) 1 else if (weighted < 0) -1 else 0
        val magnitude = abs(weighted)
        val pass = side != 0 && activeAligned >= 2 && magnitude >= 0.38 && !strongOpposition && !macroConflict
        val direction = if (!pass) "观望" else if (side > 0) "看涨" else "看跌"
        val score = (50.0 + weighted * 50.0).toInt().coerceIn(0, 100)
        // Confidence is a consistency score, deliberately not presented as a calibrated probability.
        val confidence = (50.0 + magnitude * 45.0 + (activeAligned - 2).coerceAtLeast(0) * 2.5).toInt().coerceIn(0, 95)
        val reasons = listOf(
            "江恩${label(gann.direction)}(${gann.strength.toInt()})：${gann.detail}",
            "拉什克${label(raschke.direction)}(${raschke.strength.toInt()})：${raschke.detail}",
            "威科夫${label(wyckoff.direction)}(${wyckoff.strength.toInt()})：${wyckoff.detail}",
            "大周期${if (macroConflict) "冲突" else "未见反向冲突"}"
        )
        return FusionResult(direction, score, confidence, reasons.joinToString("；"), gann, raschke, wyckoff)
    }

    private fun gann(xs: List<StrategyCandle>): ModuleSignal {
        val a = atr(xs, 14).coerceAtLeast(xs.last().close * 0.0001)
        val last = xs.last()
        val slope = (last.close - xs[xs.size - 21].close) / (a * 20.0)
        val trendDir = when { slope > 0.12 -> 1; slope < -0.12 -> -1; else -> 0 }
        val pivots = confirmedPivots(xs, 3)
        val pivot = pivots.lastOrNull()
        var timeBonus = 0.0
        var levelDir = 0
        val notes = mutableListOf<String>()
        if (pivot != null) {
            val barsSince = xs.lastIndex - pivot.first
            val cycle = listOf(7, 14, 21, 30, 45, 60).minByOrNull { abs(it - barsSince) }
            if (cycle != null && abs(cycle - barsSince) <= 1) {
                timeBonus = 15.0
                notes += "接近${cycle}根K线时间窗口"
            }
            val swing = pivots.dropLast(1).lastOrNull()
            if (swing != null) {
                val high = max(pivot.second, swing.second)
                val low = min(pivot.second, swing.second)
                val range = high - low
                if (range > a) {
                    val levels = if (pivot.second > swing.second) listOf(0.25, 1.0/3.0, 0.5, 2.0/3.0, 0.75).map { high - range * it }
                    else listOf(0.25, 1.0/3.0, 0.5, 2.0/3.0, 0.75).map { low + range * it }
                    val near = levels.minByOrNull { abs(last.close - it) }
                    if (near != null && abs(last.close - near) <= a * 0.35) {
                        levelDir = when { last.close > last.open -> 1; last.close < last.open -> -1; else -> 0 }
                        notes += "接近关键回撤位"
                    }
                }
            }
            // Square-of-Nine-style projections are treated only as confluence zones, never standalone signals.
            val root = sqrt(pivot.second.coerceAtLeast(1.0))
            val squareLevels = listOf(45.0, 90.0, 180.0, 270.0, 360.0).flatMap { degrees ->
                val step = degrees / 180.0
                listOf((root + step) * (root + step), (root - step) * (root - step)).filter { it > 0.0 }
            }
            val squareNear = squareLevels.minByOrNull { abs(last.close - it) }
            if (squareNear != null && abs(last.close - squareNear) <= a * 0.35) {
                notes += "接近九方图投影价格区"
                if (levelDir == 0) levelDir = when { last.close > last.open -> 1; last.close < last.open -> -1; else -> 0 }
            }
            if (timeBonus > 0.0 && squareNear != null && abs(last.close - squareNear) <= a * 0.35) notes += "价格与时间窗口共振"
        }
        val direction = when {
            trendDir != 0 && (levelDir == 0 || levelDir == trendDir) -> trendDir
            levelDir != 0 && timeBonus > 0 -> levelDir
            else -> 0
        }
        val strength = (abs(slope).coerceIn(0.0, 1.0) * 65.0 + timeBonus + if (levelDir == direction && direction != 0) 10.0 else 0.0).coerceIn(0.0, 100.0)
        notes.add(0, "ATR标准化角度斜率=${"%.2f".format(slope)}")
        notes += "九方图价格投影仅作观察，不单独触发交易"
        return ModuleSignal(direction, strength, notes.joinToString("、"))
    }

    private fun raschke(primary: List<StrategyCandle>, context: List<StrategyCandle>, horizonMinutes: Int): ModuleSignal {
        val last = primary.last()
        val closes = primary.map { it.close }
        // Shorter horizon uses faster averages; the 30m model deliberately smooths noise.
        val fastPeriod = if (horizonMinutes == 10) 9 else 20
        val slowPeriod = if (horizonMinutes == 10) 20 else 50
        val emaFast = ema(closes, fastPeriod)
        val emaSlow = ema(closes, slowPeriod)
        val setupEma = emaSlow
        val adxFloor = if (horizonMinutes == 10) 24.0 else 22.0
        val rsiPeriod = if (horizonMinutes == 10) 7 else 14
        val rsiNow = rsi(closes, rsiPeriod)
        val adxNow = adx(primary, 14)
        val adxPrev = adx(primary.dropLast(3), 14)
        val atrNow = atr(primary, 14).coerceAtLeast(last.close * 0.0001)
        val trend = when { emaFast > emaSlow && context.last().close >= ema(context.map { it.close }, 20) -> 1; emaFast < emaSlow && context.last().close <= ema(context.map { it.close }, 20) -> -1; else -> 0 }
        val notes = mutableListOf<String>()
        var dir = 0
        var strength = 0.0
        // Holy Grail: established trend, ADX strong/rising, EMA20 pullback and close-confirmed trigger.
        val nearEma = abs(last.close - setupEma) <= atrNow * 0.35 || primary.takeLast(3).any { abs(it.low - setupEma) <= atrNow * 0.25 || abs(it.high - setupEma) <= atrNow * 0.25 }
        if (trend != 0 && adxNow >= adxFloor && adxNow > adxPrev && nearEma) {
            val trigger = if (trend > 0) last.close > primary[primary.lastIndex - 1].high else last.close < primary[primary.lastIndex - 1].low
            if (trigger && (if (trend > 0) rsiNow in 45.0..75.0 else rsiNow in 25.0..55.0)) { dir = trend; strength = max(strength, 88.0); notes += "Holy Grail趋势回调收盘确认" }
        }
        // Turtle Soup: sweep the prior 20-bar extreme and close back inside the prior range.
        val prior = primary.dropLast(1).takeLast(20)
        if (prior.size == 20) {
            val priorLow = prior.minOf { it.low }; val priorHigh = prior.maxOf { it.high }
            if (last.low < priorLow && last.close > priorLow) { dir = 1; strength = max(strength, 82.0); notes += "Turtle Soup向下假突破收回" }
            if (last.high > priorHigh && last.close < priorHigh) { dir = -1; strength = max(strength, 82.0); notes += "Turtle Soup向上假突破回落" }
        }
        // Anti-style momentum turn: stochastic K/D cross in the direction of the established trend.
        val stochNow = stochastic(primary)
        val stochPrev = stochastic(primary.dropLast(1))
        if (trend > 0 && stochPrev.first <= stochPrev.second && stochNow.first > stochNow.second && stochNow.first < 65.0) { dir = 1; strength = max(strength, 68.0); notes += "Anti动量向上转折" }
        if (trend < 0 && stochPrev.first >= stochPrev.second && stochNow.first < stochNow.second && stochNow.first > 35.0) { dir = -1; strength = max(strength, 68.0); notes += "Anti动量向下转折" }
        // NR7: previous bar is the narrowest of seven; current close breaks its range.
        if (primary.size >= 9) {
            val seven = primary.takeLast(8).dropLast(1)
            val narrow = seven.minByOrNull { it.high - it.low }
            val prev = primary[primary.lastIndex - 1]
            if (narrow != null && prev == narrow && last.close > prev.high) { dir = 1; strength = max(strength, 72.0); notes += "NR7向上突破" }
            if (narrow != null && prev == narrow && last.close < prev.low) { dir = -1; strength = max(strength, 72.0); notes += "NR7向下突破" }
        }
        if (notes.isEmpty()) notes += "未出现有效趋势回调、假突破或动量触发"
        return ModuleSignal(dir, strength, "ADX=${"%.1f".format(adxNow)}(门槛${adxFloor.toInt()})、RSI${rsiPeriod}=${"%.1f".format(rsiNow)}、EMA${fastPeriod}/${slowPeriod}趋势=${label(trend)}、" + notes.joinToString("、"))
    }

    private fun wyckoff(xs: List<StrategyCandle>): ModuleSignal {
        val last = xs.last()
        val rangeBars = xs.dropLast(1).takeLast(20)
        val avgVol = rangeBars.map { it.volume }.average().coerceAtLeast(1e-12)
        val avgRange = rangeBars.map { it.high - it.low }.average().coerceAtLeast(last.close * 0.0001)
        val resistance = rangeBars.maxOf { it.high }
        val support = rangeBars.minOf { it.low }
        val volRatio = last.volume / avgVol
        val candleRange = (last.high - last.low).coerceAtLeast(1e-12)
        val closeLocation = (last.close - last.low) / candleRange
        val notes = mutableListOf<String>()
        var dir = 0
        var strength = 0.0
        if (last.low < support && last.close > support && closeLocation > 0.60 && volRatio >= 1.15) { dir = 1; strength = 88.0; notes += "Spring：跌破支撑后收回" }
        if (last.high > resistance && last.close < resistance && closeLocation < 0.40 && volRatio >= 1.15) { dir = -1; strength = 88.0; notes += "Upthrust：突破阻力后回落" }
        if (last.close > resistance + atr(xs, 14) * 0.10 && volRatio >= 1.25 && closeLocation > 0.70) { dir = 1; strength = max(strength, 78.0); notes += "SOS：放量有效突破区间" }
        if (last.close < support - atr(xs, 14) * 0.10 && volRatio >= 1.25 && closeLocation < 0.30) { dir = -1; strength = max(strength, 78.0); notes += "SOW：放量有效跌破区间" }
        if (volRatio >= 1.8 && candleRange <= avgRange * 0.55) {
            notes += "高成交量但价格推进有限，出现吸收迹象"
            if (strength < 70.0) { dir = 0; strength = 0.0 }
        }
        if (notes.isEmpty()) notes += "尚无明确吸筹、派发或供需突破证据"
        return ModuleSignal(dir, strength, "成交量为近期均量${"%.2f".format(volRatio)}倍、" + notes.joinToString("、"))
    }

    private fun confirmedPivots(xs: List<StrategyCandle>, wing: Int): List<Pair<Int, Double>> {
        val out = mutableListOf<Pair<Int, Double>>()
        for (i in wing until xs.size - wing) {
            val c = xs[i]
            val leftRight = (i - wing..i + wing).filter { it != i }.map { xs[it] }
            if (leftRight.all { c.high > it.high }) out += i to c.high
            else if (leftRight.all { c.low < it.low }) out += i to c.low
        }
        return out
    }

    /** Stochastic (7,10,3): raw %K over 7 bars, %D SMA10, signal SMA3 of %D. */
    private fun stochastic(xs: List<StrategyCandle>): Pair<Double, Double> {
        fun raw(end: Int): Double {
            val s = xs.subList(end - 6, end + 1)
            val lo = s.minOf { it.low }; val hi = s.maxOf { it.high }
            return if (hi <= lo) 50.0 else ((xs[end].close - lo) / (hi - lo) * 100.0).coerceIn(0.0, 100.0)
        }
        val rawValues = (xs.size - 12..xs.lastIndex).map { raw(it) }
        val dValues = rawValues.indices.filter { it >= 9 }.map { i -> rawValues.subList(i - 9, i + 1).average() }
        val d = dValues.last()
        val signal = dValues.takeLast(3).average()
        return d to signal
    }

    private fun rsi(xs: List<Double>, period: Int): Double {
        if (xs.size <= period) return 50.0
        val changes = xs.takeLast(period + 1).zipWithNext { a, b -> b - a }
        val gains = changes.filter { it > 0.0 }.sum() / period
        val losses = -changes.filter { it < 0.0 }.sum() / period
        if (losses <= 1e-12) return if (gains <= 1e-12) 50.0 else 100.0
        val rs = gains / losses
        return 100.0 - 100.0 / (1.0 + rs)
    }

    private fun ema(xs: List<Double>, period: Int): Double {
        if (xs.isEmpty()) return 0.0
        val k = 2.0 / (period + 1.0)
        return xs.drop(1).fold(xs.first()) { acc, v -> v * k + acc * (1.0 - k) }
    }

    private fun atr(xs: List<StrategyCandle>, period: Int): Double {
        if (xs.size < 2) return 0.0
        return xs.takeLast(period + 1).drop(1).mapIndexed { i, c ->
            val prev = xs[xs.size - min(xs.size, period + 1) + i]
            max(c.high - c.low, max(abs(c.high - prev.close), abs(c.low - prev.close)))
        }.average()
    }

    private fun adx(xs: List<StrategyCandle>, period: Int): Double {
        if (xs.size < period + 2) return 0.0
        var plus = 0.0; var minus = 0.0; var tr = 0.0
        val rows = xs.takeLast(period + 1)
        for (i in 1 until rows.size) {
            val a = rows[i - 1]; val b = rows[i]
            val up = b.high - a.high; val down = a.low - b.low
            if (up > down && up > 0) plus += up
            if (down > up && down > 0) minus += down
            tr += max(b.high - b.low, max(abs(b.high - a.close), abs(b.low - a.close)))
        }
        if (tr <= 0) return 0.0
        val p = plus / tr * 100.0; val m = minus / tr * 100.0
        return (abs(p - m) / (p + m).coerceAtLeast(1e-9) * 100.0).coerceIn(0.0, 100.0)
    }

    private fun label(direction: Int) = when (direction) { 1 -> "看涨"; -1 -> "看跌"; else -> "中性" }
}
