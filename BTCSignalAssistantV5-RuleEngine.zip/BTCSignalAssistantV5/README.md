# BTC 智能信号助手 V7

Android BTC/USDT spot + USDT perpetual market signal assistant. Human-confirmed signals only; it does not place orders.

## V7 changes
- Replaced the crowded single-page layout with three bottom-navigation pages: Market, Signals, and Records.
- Added an app launcher icon and a clear app name.
- Removed the independent Hall-of-Fame alert workflow and its legacy strategy voting. Historical records are preserved on-device but the Records page now focuses on SHORT signals.
- Added a transparent technical knowledge scorer for Elliott-wave structure, candlestick patterns (engulfing, pin bars, doji, consecutive candles, breakout/fakeout), volume/price behavior, support/resistance and retests, RSI/MACD/momentum/acceleration, futures sentiment, and volatility regime.
- Added Binance futures inputs for funding rate, open interest level and 5-minute OI change, global long/short account ratio, taker buy/sell ratio, top-20 order-book depth imbalance, and 24-hour quote volume.
- Existing snapshot settlement and adaptive validation remain. New adaptive weighting remains conservative and does not promote a module without held-out validation samples.

## Data limitations shown in-app
- Liquidation/forced-order stream is not yet connected; the app explicitly marks this as unavailable rather than inventing values.
- Order-book imbalance is a snapshot of the top 20 levels, not a full-depth or spoofing-resistant measure.
- OI change is based on the latest two 5-minute history points; the absolute OI value alone is not interpreted as bullish or bearish.
- Scores are rule-fit scores, not calibrated probabilities or guarantees of profit.

## Build
Use JDK 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
