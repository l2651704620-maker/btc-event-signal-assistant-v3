# BTC 信号助手 V5（修复版）

本包基于此前的 `BTCSignalAssistantV5-FullProject.zip` 修复，保留原有 V5 功能设计：

- BTCUSDT 币安合约实时标记价格 WebSocket 行情
- 独立的 10 分钟与 30 分钟 AI 分析按钮
- 10 分钟模块重点读取最近约 3 分钟走势；30 分钟模块重点读取最近约 10 分钟走势
- 结合 1m、5m、15m K 线、EMA、RSI 近似值、成交量、资金费率、持仓量和盘口快照
- 启动价格、启动时间、到期价格快照、自动结算和本机历史战绩
- 仅提供人工确认信号，不会自动下单

## 本次修复

1. `MainActivity.kt`：修正 Kotlin 字符串模板，将 `$horizon分钟` 改为 `${horizon}分钟`，避免被识别成不存在的变量 `horizon分钟`。
2. `MarketService.kt`：在 `getJson()` 函数中补上 `return`，修复缺少返回值的编译错误。

## 编译环境

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Android SDK 35

项目目录下 `.github/workflows/build-apk.yml` 可在项目本身位于仓库根目录时使用。若把本 ZIP 作为文件上传到你现有的 V3 仓库，需要同时用随包提供的 `build-apk-repo-root.yml` 替换仓库里的 `.github/workflows/build-apk.yml`，让 Actions 先解压本包再编译。

## AI 设置

首次使用需要在 App 的“AI设置”中填写兼容 OpenAI Chat Completions 的接口地址、模型名称和 API Key。密钥只保存在 App 本机私有 SharedPreferences 中。请勿分享已配置密钥的设备或备份文件；生产环境更建议使用后端代理保存密钥。

## 风险提示

AI 输出的方向和置信度是模型判断，不是经过校准的真实胜率，也不保证盈利。建议先用模拟记录验证，不要仅凭单次信号进行高风险交易。
