package com.example.btcassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.btcassistant.data.MarketService
import com.example.btcassistant.data.PredictionRecord
import com.example.btcassistant.data.SignalStore
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SignalStore.load(this)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val i=Intent(this,MarketService::class.java)
        if (Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
        setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF22C55E),background=Color(0xFF0B1220),surface=Color(0xFF172235))) { Screen(this) } }
    }
}

@Composable private fun Screen(activity: MainActivity) {
    val price by SignalStore.price.collectAsState(); val connected by SignalStore.connected.collectAsState(); val records by SignalStore.predictions.collectAsState()
    val status10 by SignalStore.status10.collectAsState(); val status30 by SignalStore.status30.collectAsState(); val aiConfigured by SignalStore.aiConfigured.collectAsState()
    var showSettings by remember { mutableStateOf(false) }
    val settled10=records.filter { it.horizon==10 && it.result!="待结算" }; val settled30=records.filter { it.horizon==30 && it.result!="待结算" }
    val wins10=settled10.count { it.result=="正确" }; val wins30=settled30.count { it.result=="正确" }
    val rate10=if(settled10.isEmpty()) 0 else wins10*100/settled10.size; val rate30=if(settled30.isEmpty()) 0 else wins30*100/settled30.size
    Surface(Modifier.fillMaxSize(), color=Color(0xFF0B1220)) {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("BTC 智能信号助手",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Color.White); Text("V5 · 双AI预测 · 人工确认，不自动下单",color=Color(0xFF94A3B8),fontSize=11.sp) }
                    TextButton(onClick={showSettings=true}) { Text("AI设置") }
                }
            }
            item { Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF172235)),shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Text("BTCUSDT 标记价格",color=Color(0xFF94A3B8),modifier=Modifier.weight(1f)); Text(if(connected) "● 已连接" else "● 连接中",color=if(connected) Color(0xFF22C55E) else Color(0xFFF59E0B),fontSize=12.sp) }; Text(if(price>0) "$"+String.format(Locale.US,"%,.2f",price) else "等待行情…",fontSize=31.sp,fontWeight=FontWeight.Bold,color=Color.White); Text("币安行情自动更新 · 断线自动重连",fontSize=11.sp,color=Color(0xFF94A3B8)) } } }
            item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Stat("10分钟胜率","$rate10%",Modifier.weight(1f)); Stat("10分钟结算",settled10.size.toString(),Modifier.weight(1f)); Stat("30分钟胜率","$rate30%",Modifier.weight(1f)); Stat("30分钟结算",settled30.size.toString(),Modifier.weight(1f)) } }
            item { PredictionPanel(10,status10,aiConfigured,records.any { it.horizon==10 && it.result=="待结算" }) { startPrediction(activity,10) } }
            item { PredictionPanel(30,status30,aiConfigured,records.any { it.horizon==30 && it.result=="待结算" }) { startPrediction(activity,30) } }
            item { Text("自动快照战绩",fontWeight=FontWeight.Bold,color=Color.White,fontSize=18.sp) }
            if(records.isEmpty()) item { Text("尚无预测记录。分别点击上方按钮启动分析。",color=Color(0xFF94A3B8),fontSize=13.sp) }
            items(records) { PredictionCard(it) }
            item { Text("预测规则：10分钟模块读取最近3分钟行情；30分钟模块读取最近10分钟行情。AI置信度至少75且方向明确才推送。到期自动记录价格并结算。历史结果保存在本机。",color=Color(0xFF64748B),fontSize=11.sp) }
        }
    }
    if(showSettings) AiSettingsDialog(activity) { showSettings=false }
}

private fun startPrediction(activity: MainActivity, horizon: Int) {
    val i=Intent(activity,MarketService::class.java).setAction(if(horizon==10) MarketService.ACTION_PREDICT_10 else MarketService.ACTION_PREDICT_30)
    if(Build.VERSION.SDK_INT>=26) activity.startForegroundService(i) else activity.startService(i)
}

@Composable private fun PredictionPanel(horizon:Int,status:String,configured:Boolean,pending:Boolean,onStart:()->Unit) {
    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF172235)),shape=RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) { Text("$horizon 分钟智能预测",fontWeight=FontWeight.Bold,color=Color.White,fontSize=18.sp,modifier=Modifier.weight(1f)); Text(if(pending) "结算中" else "独立模块",color=if(pending) Color(0xFFF59E0B) else Color(0xFF22C55E),fontSize=11.sp) }
            Text(if(horizon==10) "读取最近3分钟走势和指标，预测未来10分钟" else "读取最近10分钟走势和指标，预测未来30分钟",color=Color(0xFFCBD5E1),fontSize=13.sp)
            Text("AI：${if(configured) "已配置" else "未配置，请先设置API Key"} · 强信号门槛 75/100",color=if(configured) Color(0xFF22C55E) else Color(0xFFF59E0B),fontSize=11.sp)
            Button(onClick=onStart,enabled=configured && !pending,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp)) { Text(if(pending) "等待本笔预测结算" else "启动${horizon}分钟 AI 分析") }
            Text(status,color=Color(0xFF94A3B8),fontSize=12.sp)
        }
    }
}

@Composable private fun AiSettingsDialog(activity: MainActivity,onDismiss:()->Unit) {
    val old=remember { SignalStore.aiConfig(activity) }
    var endpoint by remember { mutableStateOf(old.first) }; var model by remember { mutableStateOf(old.second) }; var key by remember { mutableStateOf(old.third) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("AI 智能体接口设置")},text={
        Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Text("需要填写你自己的兼容 OpenAI Chat Completions 的 AI 服务信息。API Key 只保存在本机。",fontSize=12.sp,color=Color(0xFF94A3B8))
            OutlinedTextField(endpoint,{endpoint=it},label={Text("接口地址")},singleLine=true)
            OutlinedTextField(model,{model=it},label={Text("模型名称")},singleLine=true)
            OutlinedTextField(key,{key=it},label={Text("API Key")},singleLine=true,visualTransformation=PasswordVisualTransformation())
        }
    },confirmButton={TextButton(onClick={SignalStore.saveAiConfig(activity,endpoint,model,key);onDismiss()}){Text("保存")}},dismissButton={TextButton(onClick=onDismiss){Text("取消")}})
}

@Composable private fun Stat(label:String,value:String,modifier:Modifier=Modifier) { Card(modifier,colors=CardDefaults.cardColors(containerColor=Color(0xFF172235)),shape=RoundedCornerShape(12.dp)) { Column(Modifier.padding(10.dp)) { Text(label,color=Color(0xFF94A3B8),fontSize=10.sp); Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp) } } }

@Composable private fun PredictionCard(r: PredictionRecord) {
    val green=Color(0xFF22C55E); val red=Color(0xFFEF4444)
    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF172235)),shape=RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) { Text("${r.horizon}分钟 · ${r.side}",color=if(r.side=="看涨") green else red,fontWeight=FontWeight.Bold,fontSize=17.sp); Spacer(Modifier.weight(1f)); Text("置信度 ${r.confidence}%",color=Color(0xFFCBD5E1),fontSize=11.sp) }
            Text("启动价格：$"+String.format(Locale.US,"%,.2f",r.entry),color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=13.sp)
            Text("启动时间："+SimpleDateFormat("MM-dd HH:mm:ss",Locale.getDefault()).format(Date(r.createdAt)),color=Color(0xFF94A3B8),fontSize=11.sp)
            Text("AI理由：${r.reason}",color=Color(0xFFCBD5E1),fontSize=12.sp)
            Row(verticalAlignment=Alignment.CenterVertically) { Text("到期快照：",color=Color(0xFF94A3B8),fontSize=12.sp); Text(r.snapshot?.let { "$"+String.format(Locale.US,"%,.2f",it) } ?: "等待${r.horizon}分钟后记录",color=Color.White,fontSize=12.sp); Spacer(Modifier.weight(1f)); Text(r.result,color=when(r.result){"正确"->green;"错误"->red;else->Color(0xFFF59E0B)},fontWeight=FontWeight.Bold,fontSize=12.sp) }
        }
    }
}
